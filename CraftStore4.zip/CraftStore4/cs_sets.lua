function CraftStore:SETS()
	self = {}
	
	
	
	return self
end
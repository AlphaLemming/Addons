CraftStore = {
	name = 'CraftStore4',
	version = '4.00',
	author = 'AlphaLemming',
	account, character
}

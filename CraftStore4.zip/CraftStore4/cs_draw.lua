function CraftStore:DRAW()
	self = {}
	local WM = WINDOW_MANAGER
	
	function self:Button(name, parent)
		local c = WM:GetControlByName(name) or WM:CreateControl(name, parent, CT_BUTTON)
		c:SetDimensions(40,40)
		c:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
		c:SetVerticalAlignment(TEXT_ALIGN_CENTER)
		c:SetClickSound('Click')
		c:SetNormalTexture('CraftStore/grey.dds')
		c:SetMouseOverTexture('CraftStore/light.dds')
		c:SetFont('CSFont')
		c:SetNormalFontColor(1,1,1,1)
		c:SetMouseOverFontColor(1,0.66,0.2,1)
		return c
	end
	
	return self
end
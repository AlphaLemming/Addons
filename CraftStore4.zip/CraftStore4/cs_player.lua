function CraftStore:PLAYER()
	self = {}
	local EM = EVENT_MANAGER
	local SELF, CHAR = GetUnitName('player')
	local cs_panel = CraftStore:PANEL()
	local cs_traits = CraftStore:TRAITS()
	
	function self:Init(version)
		if not version then version = 1 end
		local crafting = {CRAFTING_TYPE_BLACKSMITHING, CRAFTING_TYPE_CLOTHIER, CRAFTING_TYPE_WOODWORKING}
		local account_init = {
			stock = {},
			stored = {},
			option = {true,true,true,false},
			player = {
				race = zo_strformat('<<C:1>>',GetUnitRace('player')),
				class = GetUnitClassId('player'),
				level = 1,
				elevel = GetUnitEffectiveLevel('player'),
				alliance = GetUnitAlliance('player'),
				styles = false,
				recipes = false,
				speed = 0,
				stamina = 0,
				capacity = 0,
				training = 0,
				anncounced = false,
				crafting = {},
				research = {},
				recipe = {},
				style = {},
			}
		}
		local character_init = {
			income = { GetDate(), GetCurrentMoney() },
			favorites = { {}, {}, {}, {}, {}, {} },
			recipe = 1,
			aspect = 1,
			essence = 1,
			potency = 1,
			potencytype = 1,
			enchant = ITEMTYPE_GLYPH_ARMOR,
			runemode = 'craft',
			solvent = 1,
			trait1 = 1,
			trait2 = 0,
			trait3 = 0,
			nobad = true,
			three = 1,
		}
		for _,craft in ipairs(crafting) do
			account_init.research[craft] = {}
			for line = 1, GetNumSmithingResearchLines(craft) do
				account_init.research[craft][line] = {}
				account_init.research[craft][line].active = false
				local _,_,maxtraits = GetSmithingResearchLineInfo()
				for trait = 1, maxtraits do SetTrait(craft,line,trait) end
			end
		end
		CraftStore.account = ZO_SavedVars:NewAccountWide('CS4_Account',version,nil,account_init)
		CraftStore.character = ZO_SavedVars:New('CS4_Character',version,nil,character_init)
		SetPlayerLevel()
		SetPlayerMount()
		SetPlayerSkill()
		if CraftStore.account.mainchar then CHAR = CraftStore.account.mainchar else CHAR = SELF end
	end

	function self:SetPlayer(player) CHAR = player end
	
	function self:SetPlayerStyles(val) CraftStore.account.player[CHAR].styles = val or false end
	
	function self:SetPlayerRecipes(val) CraftStore.account.player[CHAR].recipes = val or false end
	
	function self:SetPlayerAnnounced(player,val) CraftStore.account.player[player].anncounced = val or false end
	
	function self:GetPlayer() return CHAR end
	
	function self:GetPlayerValues() return CraftStore.account.player[CHAR] end
	
	function self:GetPlayerStyles() return CraftStore.account.player[CHAR].styles or false end
	
	function self:GetPlayerRecipes() return CraftStore.account.player[CHAR].recipes or false end
	
	function self:GetPlayerAnnounced(player) return CraftStore.account.player[player].anncounced or false end
	
	function self:GetCharacters()
		local function ts(t)
			local oi = {}
			for key in pairs(t) do table.insert(oi,key) end
			return table.sort(oi)
		end
		return ts(CraftStore.account.player)
	end
	
	local function SetPlayerLevel() CraftStore.account.player[SELF].level = GetUnitLevel('player') + (GetUnitVeteranRank('player') - 1) end
	
	local function SetPlayerMount()
		local ride = {GetRidingStats()}
		local ridetime = GetTimeUntilCanBeTrained()/1000
		if ridetime > 0 then ridetime = ridetime + GetTimeStamp() else ridetime = 0 end
		CraftStore.account.player[SELF].speed = ride[5]..' / '..ride[6]
		CraftStore.account.player[SELF].stamina = ride[3]..' / '..ride[4]
		CraftStore.account.player[SELF].capacity = ride[1]..' / '..ride[2]
		CraftStore.account.player[SELF].training = ridetime
	end
	
	local function GetBonus(bonus,craft)
		local level = GetNonCombatBonus(bonus) or 1
		local _,rank = GetSkillLineInfo(unpack(GetCraftingSkillLineIndices(craft)))
		return {rank, level, GetMaxSimultaneousSmithingResearch(craft) or 1}
	end
	
	local function SetPlayerSkill()
		d(SELF)
		CraftStore.account.player[SELF].crafting = {
			[CRAFTING_TYPE_BLACKSMITHING] = GetBonus(NON_COMBAT_BONUS_BLACKSMITHING_LEVEL, CRAFTING_TYPE_BLACKSMITHING),
			[CRAFTING_TYPE_CLOTHIER] = GetBonus(NON_COMBAT_BONUS_CLOTHIER_LEVEL, CRAFTING_TYPE_CLOTHIER),
			[CRAFTING_TYPE_ENCHANTING] = GetBonus(NON_COMBAT_BONUS_ENCHANTING_LEVEL, CRAFTING_TYPE_ENCHANTING),
			[CRAFTING_TYPE_ALCHEMY] = GetBonus(NON_COMBAT_BONUS_ALCHEMY_LEVEL, CRAFTING_TYPE_ALCHEMY),
			[CRAFTING_TYPE_PROVISIONING] = GetBonus(NON_COMBAT_BONUS_PROVISIONING_LEVEL, CRAFTING_TYPE_PROVISIONING),
			[CRAFTING_TYPE_WOODWORKING] = GetBonus(NON_COMBAT_BONUS_WOODWORKING_LEVEL, CRAFTING_TYPE_WOODWORKING)
		}			
	end

	function self:GetTraitNeedy(link)
		local needy = {}
		local craft, line, trait = cs_traits:FindTrait(link)
		if craft and line and trait then
			for _,char in pairs(self:GetCharacters()) do
				if self:GetTrait(craft,line,trait) == false then table.insert(needy,char) end
			end
		end
		if #needy == 0 then return false else return needy end
	end

	local function SetTrait(craft,line,trait)
		local _,_,known = GetSmithingResearchLineTraitInfo(craft,line,trait)
		local _,dur = GetSmithingResearchLineTraitTimes(craft,line,trait)
		if not known and dur > 0 then known = dur end
		CraftStore.account.player[SELF].research[craft][line][trait] = known
	end

	local function UpdateTrait(craft,line,trait)
		local _,_,known = GetSmithingResearchLineTraitInfo(craft,line,trait)
		local _,dur = GetSmithingResearchLineTraitTimes(craft,line,trait)
		if not known and dur > 0 then known = dur end
		CraftStore.account.player[SELF].research[craft][line][trait] = known
		cs_panel:UpdateTrait(craft,line,trait)
	end

	function self:GetTrait(craft,line,trait,player)
		if player and player ~= SELF then
			return CraftStore.account[player].research[craft][line][trait] or false
		else
			local t,_ = CraftStore.account[SELF].research[craft][line][trait]
			if t ~= false and t ~= true	and t > 0 then _,t = GetSmithingResearchLineTraitTimes(craft,line,trait) end
			return t
		end
	end	

	function GetTime(seconds)
		if seconds and seconds > 0 then
			local d = math.floor(seconds / 86400)
			local h = math.floor((seconds - d * 86400) / 3600)
			local m = math.floor((seconds - d * 86400 - h * 3600) / 60)
			local s = math.floor((seconds - d * 86400 - h * 3600 - m * 60))
			if d > 0 then return ('%ud %02u:%02u:%02u'):format(d,h,m,s)
			else return ('%02u:%02u:%02u'):format(h,m,s) end
		else return '|t20:20:CraftStore4/tick.dds|t' end
	end
	
	function self:GetTraitSummary(craft,line,trait)
		for _,char in pairs(self:GetCharacters()) do
			local val = self:GetTrait(craft,line,trait,char)
			if val == true then tip = tip..'\n|t20:20:esoui/art/buttons/accept_up.dds|t |c00FF00'..char..'|r'
			elseif val == false then tip = tip..'\n|t20:20:esoui/art/buttons/decline_up.dds|t |cFF1010'..char..'|r'
			elseif val and val > 0 then tip = tip..'\n|t23:23:esoui/art/mounts/timer_icon.dds|t |c66FFCC'..char..' ('..GetTime(val)..')|r' end
		end
		return tip
	end

	local function CompareItem(link1,link2)
		if not link2 then return true end
		if GetItemLinkQuality(link1) < GetItemLinkQuality(link2) then return true end
		if GetItemLinkRequiredLevel(link1) < GetItemLinkRequiredLevel(link2) then return true end
		if GetItemLinkRequiredVeteranRank(link1) < GetItemLinkRequiredVeteranRank(link2) then return true end
		return false
	end

	local function SetStored(_,_,data)
		if data.bagId > 2 then return end
		local link, uid = GetItemLink(data.bagId,data.slotId), Id64ToString(data.uniqueId)
		local a1, a2 = GetItemLinkStacks(link)
		data.cs_link = link
		if not CraftStore.account.stock[uid] then CraftStore.account.stock[uid] = {} end
		if a1 > 0 then CraftStore.account.stock[uid][SELF] = a1 else CraftStore.account.stock[uid][SELF] = nil end
		if a2 > 0 then CraftStore.account.stock[uid][1] = a2 else CraftStore.account.stock[uid][1] = nil end

		local craft,line,trait = cs_traits:FindTrait(link)
		local store = CraftStore.account.stored[craft][line][trait] or { link = false }
		
		if craft and line and trait then
			-- if action == 'added' then
				-- local owner = SELF
				-- if data.bagId == BAG_BANK then owner = CSL:String(bank) end
				-- if CompareItem(link, store.link) then
					-- CraftStore.account.stored[craft][line][trait] = { link = link, owner = owner, id = data.uid }
				-- end
			-- end
			-- if action == 'removed' and CS.account.crafting.stored[craft][line][trait].id == data.uid then
				-- CraftStore.account.stored[craft][line][trait] = nil
			-- end
			cs_panel:SetIcon(craft,line,trait)
		end
	end
	
	function self:GetStored(craft,line,trait)
		local s = CraftStore.account.stored
		if s[craft] and s[craft][line] and s[craft][line][trait] then return s[craft][line][trait] end
		return false
	end		

	EM:RegisterEvent('CraftStore_TraitUpdate', EVENT_SMITHING_TRAIT_RESEARCH_STARTED, UpdateTrait)
	EM:RegisterEvent('CraftStore_TraitUpdate', EVENT_SMITHING_TRAIT_RESEARCH_COMPLETED, UpdateTrait)
	EM:RegisterEvent('CraftStore_PlayerLevel', EVENT_LEVEL_UPDATE, SetPlayerLevel)
	EM:RegisterEvent('CraftStore_PlayerLevel', EVENT_VETERAN_RANK_UPDATE, SetPlayerLevel)
	EM:RegisterEvent('CraftStore_MountImproved', EVENT_RIDING_SKILL_IMPROVEMENT, SetPlayerMount)
	ZO_PreHook('PutPointIntoSkillAbility', SetPlayerSkill)
	ZO_PreHook('ChooseAbilityProgressionMorph', SetPlayerSkill)
	-- SHARED_INVENTORY:RegisterCallback('SlotAdded',SetStored)
	-- SHARED_INVENTORY:RegisterCallback('SlotRemoved',UnsetStored)
	-- ZO_PreHook('ZO_Skills_PurchaseAbility', SetPlayerSkill)
	-- ZO_PreHook('ZO_Skills_UpgradeAbility', SetPlayerSkill)
	-- ZO_PreHook('ZO_Skills_MorphAbility', SetPlayerSkill)
	
	return self
end
function CraftStore:STYLE()
    local self = {}
	-- function self:Init()
		-- CS.account.style.knowledge[] = {}
	-- end
	-- function self:GetStyle(player, id)
	-- end
	-- function self:SetStyle(player, id)
	-- end
	
	function self:IsRegular(style)
		if not CraftStore.styles[style] then return false end
		if CraftStore.styles[style][1] == 1 then return true end
		return false
	end

	local function IsSimpleStyle(style)
		if not CraftStore.styles[style] then return false end
		if CraftStore.styles[style][1] == 1 then return true end
		return false
	end

	function self:IsStyleKnown(style,chapter)
		if not CraftStore.styles[style] then return false end
		if IsSimpleStyle(style) then
			return IsSmithingStyleKnown(style)
		else
			local _, known = GetAchievementCriterion(CraftStore.styles[style][2],chapter)
			if known == 1 then return true end
		end
		return false
	end
	
	-- function self:GetPlayerStyle(player, id)
		-- return CS.account.style.knowledge[player][id]
	-- end
	
	function self:GetChapterId(style,chapter)
		if not CraftStore.styles[style] then CraftStore.styles[style] = {1,1028,63026} end
		if IsSimpleStyle(style) then return CraftStore.styles[style][3]
		else return CraftStore.styles[style][3] + (chapter - 1) end
	end
	
	local function GetIconAndLink(style,chapter)
		if not CraftStore.styles[style] then CraftStore.styles[style] = {1,1028,63026} end
		local link, icon = GetSmithingStyleItemInfo(style)
		local _, _, _, _, rawStyle = GetSmithingStyleItemInfo(style)
		link = ('|H1:item:%u:370:50:0:0:0:0:0:0:0:0:0:0:0:0:%u:0:0:0:10000:0|h|h'):format(CraftStore.styleitems[chapter],rawStyle)
		icon = GetItemLinkInfo(link)
		if IsSimpleStyle(style) then link = ('|H1:item:%u:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h'):format(CraftStore.styles[style][3])
		else link = ('|H1:item:%u:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h'):format(CraftStore.styles[style][3] + (chapter - 1)) end
		return icon, link
	end
	
	local function GetHeadline(style)
		if not CraftStore.styles[style] then CraftStore.styles[style] = {1,1028,63026} end
		local link, name, aName, popup
		local _, icon, _, _, rawStyle = GetSmithingStyleItemInfo(style)
		link = GetSmithingStyleItemLink(style)
		name = zo_strformat('<<C:1>>',GetString('SI_ITEMSTYLE', rawStyle))
		aLink = GetAchievementLink(CraftStore.styles[style][2],LINK_STYLE_BRACKETS)
		aName = GetAchievementInfo(CraftStore.styles[style][2])
		local _,_,_,_,progress,ts = ZO_LinkHandler_ParseLink(aLink)
		popup = {CraftStore.styles[style][2],progress,ts}
		return icon, link, name, aName, aLink, popup
	end

	function self:DrawStyles()
		local pre, icons = 0, {8,5,9,12,7,3,2,1,14,10,6,13,4,11}
		for id = 1,GetNumSmithingStyleItems() do
			local _,_,_,_,style = GetSmithingStyleItemInfo(id)
			if style ~= ITEMSTYLE_UNIVERSAL and style ~= ITEMSTYLE_NONE then
				local c = WM:GetControlByName('CS_StyleRow'..pre)
				local p = WM:CreateControl('CS_StyleRow'..id,CS_StylePanelScrollChildStyles,CT_CONTROL)
				if c then p:SetAnchor(3,c,6,0,0) else p:SetAnchor(3,nil,3,0,3) end
				p:SetDimensions(750,90)
				local bg = WM:CreateControl('CS_StylePanelScrollChildBgLine'..id,p,CT_BACKDROP)
				bg:SetAnchor(3,p,3,0,0)
				bg:SetDimensions(750,37)
				bg:SetCenterColor(0,0,0,0.2)
				bg:SetEdgeColor(1,1,1,0)

				local icon, link, name, aName, aLink, popup = GetHeadline(id)
				local btn = WM:CreateControl('CS_StylePanelScrollChildMaterial'..id,p,CT_BUTTON)
				btn:SetAnchor(2,bg,2,10,0)
				btn:SetDimensions(30,30)
				btn:SetNormalTexture(icon)
				btn:EnableMouseButton(2,true)
				btn:SetHandler('OnMouseEnter',function(self) CS.Tooltip(self,true,false,CS_Style,'tl') end)
				btn:SetHandler('OnMouseExit',function(self) CS.Tooltip(self,false) end)
				btn:SetHandler('OnMouseDown',function(self,button) if button == 2 then ToChat(self.data.link) end end)
				btn.data = { link = link, buttons = {L.TT[6]} }
				
				local lbl = WM:CreateControl('CS_StylePanelScrollChildName'..id,p,CT_LABEL)
				lbl:SetAnchor(2,bg,2,50,0)
				lbl:SetDimensions(nil,32)
				lbl:SetFont('CSFont')
				lbl:SetText(name)
				lbl:SetColor(1,0.66,0.2,1)
				lbl:SetHorizontalAlignment(0)
				lbl:SetVerticalAlignment(1)

				local av = WM:CreateControl('CS_StylePanelScrollChildAchievment'..id,p,CT_BUTTON)
				av:SetAnchor(2,lbl,8,15,0)
				av:SetDimensions(300,32)
				av:SetFont('CSFont')
				av:SetNormalFontColor(1,0.66,0.2,0.5)
				av:SetMouseOverFontColor(1,0.66,0.2,1)
				av:SetHorizontalAlignment(0)
				av:SetVerticalAlignment(1)
				av:EnableMouseButton(2,true)
				av:SetText('['..aName..']')
				av:SetHandler('OnMouseDown',function(self,button)
					if button == 2 then	ToChat(aLink) else
						ACHIEVEMENTS:ShowAchievementPopup(unpack(popup))
						ZO_PopupTooltip_Hide()
					end 
				end)
				for z,y in pairs(icons) do
					icon, link = GetIconAndLink(id,y)
					local btn = WM:CreateControl('CS_StylePanelScrollChild'..id..'Button'..y,p,CT_BUTTON)
					btn:SetAnchor(3,bg,6,4+(z-1)*52,2)
					btn:SetDimensions(52,50)
					btn:EnableMouseButton(2,true)
					btn:SetClickSound('Click')
					btn:SetHandler('OnMouseEnter',function(self) CS.Tooltip(self,true,true,CS_Style,'tl') end)
					btn:SetHandler('OnMouseExit',function(self) CS.Tooltip(self,false,true) end)
					btn:SetHandler('OnMouseDown',function(self,button) if button == 2 then ToChat(self.data.link) end end)
					btn.data = { link = link, buttons = {L.TT[6]} }
					local tex = WM:CreateControl('$(parent)Texture',btn,CT_TEXTURE)
					tex:SetAnchor(128,btn,128,0,0)
					tex:SetDimensions(45,45)
					tex:SetColor(1,0,0,0.5)
					tex:SetTexture(icon)
				end
				pre = id
			end
		end
	end

	return self
end
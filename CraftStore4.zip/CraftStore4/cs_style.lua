function CraftStore:STYLE()
    local self = {}
	local LANG = CraftStore:LANGUAGE()
	local TOOLS = CraftStore:TOOLS()
	local PLAYER = CraftStore:PLAYER()
	local EM, WM = EVENT_MANAGER, WINDOW_MANAGER
	local SELF = GetUnitName('player')
	local icons = {8,5,9,12,7,3,2,1,14,10,6,13,4,11}

	local function IsSimpleStyle(style)
		if not CraftStore.styles[style] then return false end
		if CraftStore.styles[style][1] == 1 then return true end
		return false
	end

	local function IsStyleKnown(style,chapter)
		if not CraftStore.styles[style] then return false end
		if IsSimpleStyle(style) then
			return IsSmithingStyleKnown(style)
		else
			local _,known = GetAchievementCriterion(CraftStore.styles[style][2],chapter)
			if known == 1 then return true end
		end
		return false
	end
	
	local function GetChapterId(style,chapter)
		if not CraftStore.styles[style] then return false end
		if IsSimpleStyle(style) then return CraftStore.styles[style][3]
		else return CraftStore.styles[style][3] + (chapter - 1) end
	end
	
	local function GetIconAndLink(style,chapter)
		if not CraftStore.styles[style] then return false end
		local link, icon, pos, _, rawStyle, item = GetSmithingStyleItemInfo(style)
		local armor = CraftStore.character.style_armor or 1
		if armor == 1 then armor = CRAFTING_TYPE_CLOTHIER; pos = 0
		elseif armor == 2 then armor = CRAFTING_TYPE_CLOTHIER; pos = 7
		elseif armor == 3 then armor = CRAFTING_TYPE_BLACKSMITHING; pos = 7 end
		item = CraftStore.styleitems[chapter]
		if item[1] == 0 then item[1] = armor; item[2] = item[2] + pos end
		item = CraftStore.traititems[item[1]][item[2]]		
		-- link = ('|H1:item:%u:370:50:0:0:0:0:0:0:0:0:0:0:0:0:%u:0:0:0:10000:0|h|h'):format(item,rawStyle)
		icon = GetItemLinkInfo(('|H1:item:%u:370:50:0:0:0:0:0:0:0:0:0:0:0:0:%u:0:0:0:10000:0|h|h'):format(item,rawStyle))
		if IsSimpleStyle(style) then link = ('|H1:item:%u:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h'):format(CraftStore.styles[style][3])
		else link = ('|H1:item:%u:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h'):format(CraftStore.styles[style][3] + (chapter - 1)) end
		return icon, link
	end
	
	local function GetHeadline(style)
		if not CraftStore.styles[style] then return false end
		local link, name, aName, popup
		local _, icon, _, _, rawStyle = GetSmithingStyleItemInfo(style)
		link = GetSmithingStyleItemLink(style)
		name = zo_strformat('<<C:1>>',GetString('SI_ITEMSTYLE', rawStyle))
		aLink = GetAchievementLink(CraftStore.styles[style][2],LINK_STYLE_BRACKETS)
		aName = GetAchievementInfo(CraftStore.styles[style][2])
		local _,_,_,_,progress,ts = ZO_LinkHandler_ParseLink(aLink)
		popup = {CraftStore.styles[style][2],progress,ts}
		return icon, link, name, aName, aLink, popup
	end

	function self:GetStyle(player,id)
		return CraftStore.account.player[player].styles[id] or false
	end

	local function SetStyle(style,chapter)
		CraftStore.account.player[SELF].styles[GetChapterId(style,chapter)] = IsStyleKnown(style,chapter)
	end
	
	local function UpdateStyle(_,style,chapter)
		CraftStore.account.player[SELF].styles[GetChapterId(style,chapter)] = IsStyleKnown(style,chapter)
	end

	local function GetKnownChapter(style)
		if not CraftStore.styles[style] then return '' end
		local count = 0
		if IsSimpleStyle(style) then
			if self:GetStyle(PLAYER:GetPlayer(),style) then return ' (|c44FF4414/14|r)' else return ' (|cFF44440/14|r)' end
		else
			for chapter = 1,14 do if self:GetStyle(PLAYER:GetPlayer(),GetChapterId(style,chapter)) then count = count + 1 end end
			if count == 0 then return ' (|cFF44440/14|r)'
			elseif count < 14 then return ' (|cFFDD66'..count..'/14|r)'
			elseif count == 14 then return ' (|c44FF4414/14|r)' end
		end
	end

	function SetActiveList()
		for id,_ in ipairs(CraftStore.styles) do
			local _,_,name = GetHeadline(id)
			local c = WM:GetControlByName('CS4_StyleListScrollChildStylename'..id)
			c:SetText(name..GetKnownChapter(id))
		end
	end
	
	function SetActiveStyle()
		local id = CraftStore.character.style_active or 2
		local icon, link, name, aName, aLink, popup = GetHeadline(id)
		CS4_StyleStyleitem:SetTexture(icon)
		CS4_StyleStyleitem.cs_data = { link = link, anchor = {3,CS4_Style,9,2,0} }
		CS4_StyleHeaderName:SetText(name)
		CS4_StyleHeaderItemname:SetText(zo_strformat('<<C:1>>',GetItemLinkName(link)))
		CS4_StyleHeaderAchieve:SetText('['..aName..']')
		CS4_StyleHeaderAchieve.cs_data = { link = aLink, popup = popup }
		for _,chapter in ipairs(icons) do
			local c,t = WM:GetControlByName('CS4_StyleIcon'..chapter)
			local icon, link = GetIconAndLink(id,chapter)
			if c then
				c.cs_data = { link = link, anchor = {3,CS4_Style,9,2,0}, line = {} }
				t = c:GetNamedChild('Texture')
				t:SetTexture(icon)
				if self:GetStyle(PLAYER:GetPlayer(),id,chapter) then t:SetColor(1,1,1,1) else t:SetColor(1,0,0,1) end
			end
		end
	end
	
	function self:DrawStyles()
		local xpos, ypos, c, t = 0, 0
		for nr,tex in ipairs(icons) do
			c = WM:CreateControl('$(parent)Icon'..tex,CS4_Style,CT_BUTTON)
			c:SetAnchor(3,CS4_Style,3,10+xpos,95+ypos)
			c:SetDimensions(68,68)
			c:EnableMouseButton(2,true)
			c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
			c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			c:SetHandler('OnMouseDown', function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) end end)
			t = WM:CreateControl('$(parent)Texture',c,CT_TEXTURE)
			c:SetAnchor(128,c,128,0,0)
			c:SetDimensions(64,64)
			if nr%1 == 0 then ypos = ypos + 68 end
			if nr%2 == 0 then xpos = 68 else xpos = 0 end
		end
		ypos = 0
		for id,_ in ipairs(CraftStore.styles) do
			local _,_,name = GetHeadline(id)
			c = WM:CreateControl('$(parent)Stylename'..id,CS4_StyleListScrollChild,CT_BUTTON)
			c:SetAnchor(3,CS4_StyleListScrollChild,3,7,ypos)
			c:SetDimensions(280,23)
			c:SetText(name)
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetClickSound('Click')
			c:SetFont('CSFont')
			c:SetNormalColor(1,1,1,1)
			c:SetMouseOverColor(1,0.66,0.2,1)
			c:SetHandler('OnClicked', function() CraftStore.character.style_active = id; SetActiveStyle() end)
			ypos = ypos + 23
		end
		CS4_StyleListScrollChild:SetHeight(ypos-20)
		CS4_StyleList.useFadeGradient = false
		CS4_StyleStyleitem:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		CS4_StyleStyleitem:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		CS4_StyleStyleitem:SetHandler('OnMouseDown', function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) end end)
		CS4_StyleHeaderAchieve:SetHandler('OnMouseDown',function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) else ACHIEVEMENTS:ShowAchievementPopup(unpack(self.cs_data.popup)); ZO_PopupTooltip_Hide() end end)
		CS4_StyleLight:SetText(LANG:Get('light')
		CS4_StyleLight:SetHandler('OnClicked',function(self) CraftStore.character.style_armor = 1; SetActiveStyle() end)
		CS4_StyleMedium:SetText(LANG:Get('medium')
		CS4_StyleMedium:SetHandler('OnClicked',function(self) CraftStore.character.style_armor = 2; SetActiveStyle() end)
		CS4_StyleHeavy:SetText(LANG:Get('heavy')
		CS4_StyleHeavy:SetHandler('OnClicked',function(self) CraftStore.character.style_armor = 3; SetActiveStyle() end)
	end

	function self:Init()
		CraftStore.account.player[SELF].styles = {}
		for style,_ in pairs(CraftStore.styles) do
			if IsSimpleStyle(style) then SetStyle(style)
			else for chapter = 1,14 do SetStyle(style,chapter) end end
		end
		EM:RegisterForEvent('CraftStore_StyleLearned', EVENT_STYLE_LEARNED, UpdateStyle)
	end

	return self
end
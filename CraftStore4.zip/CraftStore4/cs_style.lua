function CraftStore:STYLE()
    local self = {}
	local LANG = CraftStore:LANGUAGE()
	local TOOLS = CraftStore:TOOLS()
	local PLAYER = CraftStore:PLAYER()
	local EM, WM = EVENT_MANAGER, WINDOW_MANAGER
	local SELF = GetUnitName('player')

	local function IsSimpleStyle(style)
		if not CraftStore.styles[style] then return false end
		if CraftStore.styles[style][1] == 1 then return true end
		return false
	end

	local function IsStyleKnown(style,chapter)
		if not CraftStore.styles[style] then return false end
		if IsSimpleStyle(style) then
			return IsSmithingStyleKnown(style)
		else
			local _,known = GetAchievementCriterion(CraftStore.styles[style][2],chapter)
			if known == 1 then return true end
		end
		return false
	end
	
	local function GetChapterId(style,chapter)
		if not CraftStore.styles[style] then return false end
		if IsSimpleStyle(style) then return CraftStore.styles[style][3]
		else return CraftStore.styles[style][3] + (chapter - 1) end
	end
	
	local function GetIconAndLink(style,chapter)
		if not CraftStore.styles[style] then return false end
		local link, icon, pos, _, rawStyle, item = GetSmithingStyleItemInfo(style)
		local armor, craft, line, nr, weap = CraftStore.character.style_armor
		if armor == 1 then craft = CRAFTING_TYPE_CLOTHIER; pos = 0; weap = -3
		elseif armor == 2 then craft = CRAFTING_TYPE_CLOTHIER; pos = 7; weap = 0
		elseif armor == 3 then craft = CRAFTING_TYPE_BLACKSMITHING; pos = 7; weap = 0 end
		line = CraftStore.styleitems[chapter][1]
		nr = CraftStore.styleitems[chapter][2]
		if line == 0 then line = craft; nr = nr + pos end
		if line ~= 0 and nr < 7 and CraftStore.styleitems[chapter][1] == CRAFTING_TYPE_BLACKSMITHING then nr = nr + weap end
		item = CraftStore.traititems[line][nr]		
		icon = GetItemLinkInfo(('|H1:item:%u:370:50:0:0:0:0:0:0:0:0:0:0:0:0:%u:0:0:0:10000:0|h|h'):format(item,rawStyle))
		if IsSimpleStyle(style) then link = ('|H1:item:%u:5:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h'):format(CraftStore.styles[style][3])
		else link = ('|H1:item:%u:6:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h'):format(CraftStore.styles[style][3] + (chapter - 1)) end
		return icon, link
	end
	
	local function GetHeadline(style)
		if not CraftStore.styles[style] then return false end
		local link, name, aName, popup
		local _, icon, _, _, rawStyle = GetSmithingStyleItemInfo(style)
		link = GetSmithingStyleItemLink(style)
		name = zo_strformat('<<C:1>>',GetString('SI_ITEMSTYLE', rawStyle))
		aLink = GetAchievementLink(CraftStore.styles[style][2],LINK_STYLE_BRACKETS)
		aName = GetAchievementInfo(CraftStore.styles[style][2])
		local _,_,_,_,progress,ts = ZO_LinkHandler_ParseLink(aLink)
		popup = {CraftStore.styles[style][2],progress,ts}
		return icon, link, name, aName, aLink, popup
	end

	function self:GetStyle(player,id)
		return CraftStore.account.player[player].styles[id] or false
	end

	local function SetStyle(style,chapter)
		CraftStore.account.player[SELF].styles[GetChapterId(style,chapter)] = IsStyleKnown(style,chapter)
	end
	
	local function UpdateStyle(_,style,chapter)
		CraftStore.account.player[SELF].styles[GetChapterId(style,chapter)] = IsStyleKnown(style,chapter)
	end

	local function GetKnownChapter(style)
		if not CraftStore.styles[style] then return '' end
		local count = 0
		if IsSimpleStyle(style) then
			if self:GetStyle(PLAYER:GetPlayer(),GetChapterId(style,chapter)) then return '  ( |c44FF4414 / 14|r )' else return '  ( |cFF44440 / 14|r )' end
		else
			for chapter = 1,14 do if self:GetStyle(PLAYER:GetPlayer(),GetChapterId(style,chapter)) then count = count + 1 end end
			if count == 0 then return '  ( |cFF44440 / 14|r )'
			elseif count < 14 then return '  ( |cFFDD66'..count..' / 14|r )'
			elseif count == 14 then return '  ( |c44FF4414 / 14|r )' end
		end
	end

	local function SetActiveList()
		for id,_ in pairs(CraftStore.styles) do
			local _,_,_,_,rawStyle = GetSmithingStyleItemInfo(id)
			local name = zo_strformat('<<C:1>>',GetString('SI_ITEMSTYLE', rawStyle))
			local c = WM:GetControlByName('CS4_StyleListScrollChildStylename'..id)
			c:SetText(name..GetKnownChapter(id))
		end
	end
	
	function self:SetActiveStyle()
		local id = CraftStore.character.style_active or 2
		local icon, link, name, aName, aLink, popup = GetHeadline(id)
		CS4_StyleStyleitemTexture:SetTexture(icon)
		CS4_StyleStyleitem.cs_data = { link = link, anchor = {CS4_Style,3,9,2,0} }
		CS4_StyleHeaderName:SetText(zo_strformat('<<Z:1>>',name))
		CS4_StyleHeaderAchieve:SetText('['..aName..']')
		CS4_StyleHeaderAchieve.cs_data = { link = aLink, popup = popup }
		for _,chapter in pairs(CraftStore.icons) do
			local c,t = WM:GetControlByName('CS4_StyleIcon'..chapter)
			local icon, link = GetIconAndLink(id,chapter)
			if c then
				c.cs_data = { link = link, anchor = {CS4_Style,3,9,2,0} }
				t = c:GetNamedChild('Texture')
				t:SetTexture(icon)
				if self:GetStyle(PLAYER:GetPlayer(),GetChapterId(id,chapter)) then t:SetColor(1,1,1,1) else t:SetColor(1,0,0,1) end
			end
		end
	end
	
	function self:Init()
		CraftStore.account.player[SELF].styles = {}
		for style,_ in pairs(CraftStore.styles) do
			if IsSimpleStyle(style) then SetStyle(style)
			else for chapter = 1,14 do SetStyle(style,chapter) end end
		end
		EM:RegisterForEvent('CraftStore_StyleLearned', EVENT_STYLE_LEARNED, UpdateStyle)
		SetActiveList()
		self:SetActiveStyle()
	end

	return self
end
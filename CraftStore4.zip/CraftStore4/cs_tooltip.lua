function CraftStore:TOOLTIP()
	self = {}
	local TRAIT = CraftStore:TRAIT()
	local STYLE = CraftStore:STYLE()
	local PLAYER = CraftStore:PLAYER()
	local TOOLS = CraftStore:TOOLS()
	local LANG = CraftStore:LANGUAGE()
	local count = 0
	local bait = { [42877] = 1,[42871] = 2,[42873] = 2,[42872] = 3,[42874] = 3,[42870] = 4,[42876] = 4,[42875] = 5,[42869] = 5 }

	local function FadeIn(c)
		local a = ANIMATION_MANAGER:CreateTimeline()
		local fade = a:InsertAnimation(ANIMATION_ALPHA,c)
		c:SetAlpha(0)
		c:SetHidden(false)
		fade:SetAlphaValues(0,1)
		fade:SetDuration(150)
		a:PlayFromStart()
	end

	local function FadeOut(c)
		local a = ANIMATION_MANAGER:CreateTimeline()
		local fade = a:InsertAnimation(ANIMATION_ALPHA,c)
		fade:SetAlphaValues(1,0)
		fade:SetDuration(100)
		a:PlayFromStart()
		zo_callLater(function() c:SetHidden(true) end, 110)
	end
	
	local function Insert(c,data,font)
		c:AddVerticalPadding(5)
		c:AddLine(data,font or 'CS4Font')
	end
	
	local function Info(c,text,upper)
		CS4_TipStyle:SetAnchor(4,c,4,-1,-2)
		if upper then CS4_TipStyleName:SetText(zo_strformat('<<ZC:1>>',text))
		else CS4_TipStyleName:SetText(zo_strformat('<<C:1>>',text)) end
		CS4_TipStyle:SetHidden(false)
	end

	function self:ShowTooltip(c)
		if c.cs_data then
			local a = c.cs_data.anchor
			if c.cs_data.link then
				c.tt = ItemTooltip
				InitializeTooltip(c.tt,a[1],a[2],a[4],a[5],a[3])
				c.tt:SetLink(c.cs_data.link)
				ZO_ItemTooltip_ClearCondition(c.tt)
				ZO_ItemTooltip_ClearCharges(c.tt)
			elseif c.cs_data.info then
				c.tt = InformationTooltip
				InitializeTooltip(c.tt,a[1],a[2],a[4],a[5],a[3])
				SetTooltipText(c.tt,c.cs_data.info)
			end
			if c.cs_data.line then for _,data in pairs(c.cs_data.line) do Insert(c.tt,data) end end
			c.tt:SetHidden(false)
		end
	end

	function self:HideTooltip(c)
		if not c.tt then return end
		c.tt:SetHidden(true)
		ClearTooltip(c.tt)
		c.tt = nil
	end

	local function IsItemNeeded(craft,line,trait,id)
		if not craft or not line or not trait then return end
		local isSelf, needy, store = false, {}, CraftStore.account.stored[craft..'&'..line..'&'..trait] or false
		if (store and store.id == id) or (not id and not store) then
			for _,char in pairs(TOOLS:GetCharacters()) do
				local res = CraftStore.account.player[char].research[craft][line]
				if res.active and not res[trait] then
					if PLAYER:GetIsSelf(char) then isSelf = true end
					table.insert(needy,'|t14:14:CraftStore4/cross.dds|t |cFF4444'..char..'|r')
				end
			end
		end
		return table.concat(needy,'\n'), isSelf
	end
	
	local function IsStyleNeeded(link)
		local style, needy = TOOLS:SplitLink(link,3), {}
		for _,char in pairs(TOOLS:GetCharacters()) do
			if not STYLE:GetStyle(char,style) then
				if PLAYER:GetIsSelf(char) then isSelf = true end
				table.insert(needy,'|t14:14:CraftStore4/cross.dds|t |cFF4444'..char..'|r')
			end
		end
		return table.concat(needy,'\n'), isSelf
	end

	local function IsBait(link)
		if not link then return '' end
		local id = TOOLS:SplitLink(link,3)
		if id then return LANG:Get('bait')[bait[id]] end
		return ''
	end

	local function IsPotency(link)
		if not link then return '' end
		local id = TOOLS:SplitLink(link,3)
		for pos,add in pairs(CraftStore.runes[ITEMTYPE_ENCHANTING_RUNE_POTENCY]) do
			for level,rune in pairs(add) do
				if rune == id then return LANG:Get('level')..' '..CraftStore.runelevels[level]..' - '..LANG:Get('potency')[pos] end
			end
		end
		return ''
	end

	local function HideTooltips()
		CS4_Tip:SetHidden(true)
		CS4_TipStyle:SetHidden(true)
	end
	
	local function TooltipShow(c,link,uid)
		if not link then return end
		HideTooltips()
		local it, needy = GetItemLinkItemType(link), ''
		if CraftStore.account.option[1] then
			if it == ITEMTYPE_RACIAL_STYLE_MOTIF then needy = IsStyleNeeded(link) end
		end
		-- if CraftStore.account.option[2] then
			-- if it == ITEMTYPE_RECIPE then needy = cs_cook:IsRecipeNeeded(link)
		-- end
		if CraftStore.account.option[3] then
			if it == ITEMTYPE_LURE then Info(c,IsBait(link)) end
		end
		if CraftStore.account.option[4] then
			if it == ITEMTYPE_ENCHANTING_RUNE_POTENCY then Info(c,IsPotency(link)) end
		end
		if CraftStore.account.option[6] then
			local craft, line, trait = TRAIT:FindTrait(link)
			if craft and line and trait then needy = IsItemNeeded(craft,line,trait,uid) end
		end
		if CraftStore.account.option[6] then
			local count, name, store, id = 0, {}, {}, TOOLS:SplitLink(link,3)
			if CraftStore.account.stock[id] then
				for loc, stock in TOOLS:spairs(CraftStore.account.stock[id]) do
					count = count + stock
					if loc == 'aa' then loc = LANG:Get('bank') end
					table.insert(name,loc)
					table.insert(store,stock)
				end
				if #store > 0 and count > 1 then
					CS4_Tip:SetHeight(#store*20+35)
					CS4_TipBG:SetHeight(#store*20+75)
					CS4_TipName:SetText(table.concat(name,'\n'))
					CS4_TipAmount:SetText(table.concat(store,'\n'))
					CS4_TipCount:SetText(count)
					CS4_Tip:ClearAnchors()
					CS4_Tip:SetAnchor(4,c,1,0,-5)
					CS4_Tip:SetHidden(false)
				end
			end
		end
		if CraftStore.account.option[5] then
			if it == ITEMTYPE_WEAPON or it == ITEMTYPE_ARMOR then Info(c,GetString('SI_ITEMSTYLE',GetItemLinkItemStyle(link)),true) end
		end
		if needy ~= '' then Insert(c,needy) end
	end

	function self:TooltipHandler()
		local tt = ItemTooltip.SetBagItem
		ItemTooltip.SetBagItem = function(c,bag,slot,...)
			tt(c,bag,slot,...)
			TooltipShow(c,GetItemLink(bag,slot),Id64ToString(GetItemUniqueId(bag,slot)))
		end
		local tt = ItemTooltip.SetLootItem
		ItemTooltip.SetLootItem = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetLootItemLink(id))
		end
		local tt = ZO_SmithingTopLevelCreationPanelResultTooltip.SetPendingSmithingItem
		ZO_SmithingTopLevelCreationPanelResultTooltip.SetPendingSmithingItem = function(c,pid,mid,mq,sid,tid)
			tt(c,pid,mid,mq,sid,tid)
			TooltipShow(c,GetSmithingPatternResultLink(pid,mid,mq,sid,tid))
		end	
		local tt = PopupTooltip.SetLink
		PopupTooltip.SetLink = function(c,link,...)
			tt(c,link,...)
			TooltipShow(c,link)
		end
		local tt = ItemTooltip.SetAttachedMailItem
		ItemTooltip.SetAttachedMailItem = function(c,oid,aid,...)
			tt(c,oid,aid,...)
			TooltipShow(c,GetAttachedItemLink(oid,aid))
		end
		local tt = ItemTooltip.SetBuybackItem
		ItemTooltip.SetBuybackItem = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetBuybackItemLink(id))
		end
		local tt = ItemTooltip.SetTradingHouseItem
		ItemTooltip.SetTradingHouseItem = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetTradingHouseSearchResultItemLink(id))
		end
		local tt = ItemTooltip.SetTradingHouseListing
		ItemTooltip.SetTradingHouseListing = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetTradingHouseListingItemLink(id))
		end
		local tt = ItemTooltip.SetTradeItem
		ItemTooltip.SetTradeItem = function(c,_,slot,...)
			tt(c,_,slot,...)
			TooltipShow(c,GetTradeItemLink(slot))
		end
		local tt = ItemTooltip.SetQuestReward
		ItemTooltip.SetQuestReward = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetQuestRewardItemLink(id))
		end
		ZO_PreHookHandler(ItemTooltip,'OnHide',HideTooltips)
		ZO_PreHookHandler(PopupTooltip,'OnHide',HideTooltips)
		ZO_PreHookHandler(ZO_SmithingTopLevel,'OnHide',HideTooltips)
		ZO_PreHookHandler(ZO_SmithingTopLevelCreationPanelResultTooltip,'OnHide',HideTooltips)
	end

	return self
end

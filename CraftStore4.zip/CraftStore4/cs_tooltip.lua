function CraftStore:TOOLTIP()
	self = {}
	local TRAITS = CraftStore:TRAITS()
	local STYLE = CraftStore:STYLE()
	local PLAYER = CraftStore:PLAYER()
	local TOOLS = CraftStore:TOOLS()

	local function FadeIn(c)
		local a = ANIMATION_MANAGER:CreateTimeline()
		local fade = a:InsertAnimation(ANIMATION_ALPHA,c)
		c:SetAlpha(0)
		c:SetHidden(false)
		fade:SetAlphaValues(0,1)
		fade:SetDuration(150)
		a:PlayFromStart()
	end

	local function FadeOut(c)
		local a = ANIMATION_MANAGER:CreateTimeline()
		local fade = a:InsertAnimation(ANIMATION_ALPHA,c)
		fade:SetAlphaValues(1,0)
		fade:SetDuration(100)
		a:PlayFromStart()
		zo_callLater(function() c:SetHidden(true) end, 110)
	end
	
	local function Insert(c,data,font)
		c:AddVerticalPadding(5)
		c:AddLine(data,font or 'CS4Font')
	end

	function self:ShowTooltip(c)
		if c.cs_data then
			local a = c.cs_data.anchor
			if c.cs_data.link then
				c.tt = ItemTooltip
				InitializeTooltip(c.tt,a[1],a[2],a[4],a[5],a[3])
				c.tt:SetLink(c.cs_data.link)
				ZO_ItemTooltip_ClearCondition(c.tt)
				ZO_ItemTooltip_ClearCharges(c.tt)
			elseif c.cs_data.info then
				c.tt = InformationTooltip
				InitializeTooltip(c.tt,a[1],a[2],a[4],a[5],a[3])
				SetTooltipText(c.tt,c.cs_data.info)
			end
			if c.cs_data.line then for _,data in pairs(c.cs_data.line) do Insert(c.tt,data) end end
			c.tt:SetHidden(false)
		end
	end

	function self:HideTooltip(c)
		if not c.tt then return end
		c.tt:SetHidden(true)
		ClearTooltip(c.tt)
		c.tt = nil
	end

	local function IsItemNeeded(craft,line,trait,id,link)
		if not craft or not line or not trait then return end
		local isSet = GetItemLinkSetInfo(link)
		local isSelf, needy, storedId = false, {}, CraftStore.account.stored[craft][line][trait].id or 0
		if not isSet and (storedId == id or (not id and storedId == 0)) then
			for _,char in pairs(TOOLS:GetCharacters()) do
				if CraftStore.account[char].research[craft][line].active and not CraftStore.account[char].research[craft][line][trait] then
					if PLAYER:GetSelf(char) then isSelf = true end
					table.insert(needy,'|t24:24:CraftStore4/cross.dds|t |cFF1010'..char..'|r')
				end
			end
		end
		return table.concat(needy,'\n'), isSelf
	end

	local function TooltipShow(c,link,uid)
		if not link then return end
		CS4_Tip:SetHidden(true)
		CS4_TipStyle:SetHidden(true)
		local it, needy = GetItemLinkItemType(link), ''
		-- if CraftStore.account.option[1] then
			-- if it == ITEMTYPE_RACIAL_STYLE_MOTIF then needy = STYLE:IsStyleNeeded(link)
		-- end
		-- if CraftStore.account.option[2] then
			-- if it == ITEMTYPE_RECIPE then needy = cs_cook:IsRecipeNeeded(link)
		-- end
		-- if CraftStore.account.option[3] then
			-- if it == ITEMTYPE_LURE then needy = IsBait(link)
		-- end
		-- if CraftStore.account.option[4] then
			-- if it == ITEMTYPE_ENCHANTING_RUNE_POTENCY then needy = IsPotency(link)
		-- end
		if CraftStore.account.option[5] then
			local style = GetItemLinkItemStyle(link)
			-- if style ~= ITEMSTYLE_NONE then Insert(c,'|cC5C29E'..zo_strformat('<<ZC:1>>',GetString('SI_ITEMSTYLE',style))..'|r') end
			if style ~= ITEMSTYLE_NONE then
				c:AddControl(CS4_TipStyle)
				CS4_TipStyle:SetAnchor(128,c,4,0,0)
				CS4_TipStyleName:SetText(zo_strformat('<<ZC:1>>',GetString('SI_ITEMSTYLE',style)))
				CS4_TipStyle:SetHidden(false)
			end
		end
		-- if CraftStore.account.option[6] then
			-- local craft, line, trait = TRAITS:FindTrait(link)
			-- if craft and line and trait then needy = PLAYER:IsItemNeeded(craft,line,trait,uid,link) end
		-- end
		if CraftStore.account.option[6] then
			local count, name, store, id = 0, {}, {}, TOOLS:SplitLink(link,3)
			if CraftStore.account.stock[id] then
				for loc, stock in TOOLS:spairs(CraftStore.account.stock[id]) do
					count = count + stock
					if loc == 'aa' then loc = 'Bank' end
					table.insert(name,loc)
					table.insert(store,stock)
				end
				if #store > 0 and count > 1 then
					c:AddVerticalPadding(5)   
					c:AddControl(CS4_Tip)
					CS4_Tip:SetAnchor(CENTER)
					local w,h = c:GetWidth()-10, #store*22+10
					CS4_Tip:SetDimensions(w,h)
					CS4_TipName:SetWidth(w-170)
					CS4_TipName:SetText(table.concat(name,'\n'))
					CS4_TipAmount:SetText(table.concat(store,'\n'))
					if #store > 1 then CS4_TipCount:SetText(count) else CS4_TipCount:SetText('') end
					CS4_Tip:SetHidden(false)
				end
			end
		end
		if needy ~= '' then Insert(c,needy) end
	end

	function self:TooltipHandler()
		local tt = ItemTooltip.SetBagItem
		ItemTooltip.SetBagItem = function(c,bag,slot,...)
			tt(c,bag,slot,...)
			-- TooltipShow(c,GetItemLink(bag,slot),Id64ToString(GetItemUniqueId(bag,slot)),tostring(GetItemInstanceId(bag,slot)))
			TooltipShow(c,GetItemLink(bag,slot),Id64ToString(GetItemUniqueId(bag,slot)))
		end
		local tt = ItemTooltip.SetLootItem
		ItemTooltip.SetLootItem = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetLootItemLink(id))
		end
		local tt = ZO_SmithingTopLevelCreationPanelResultTooltip.SetPendingSmithingItem
		ZO_SmithingTopLevelCreationPanelResultTooltip.SetPendingSmithingItem = function(c,pid,mid,mq,sid,tid)
			tt(c,pid,mid,mq,sid,tid)
			TooltipShow(c,GetSmithingPatternResultLink(pid,mid,mq,sid,tid))
		end	
		local tt = PopupTooltip.SetLink
		PopupTooltip.SetLink = function(c,link,...)
			tt(c,link,...)
			TooltipShow(c,link)
		end
		local tt = ItemTooltip.SetAttachedMailItem
		ItemTooltip.SetAttachedMailItem = function(c,oid,aid,...)
			tt(c,oid,aid,...)
			TooltipShow(c,GetAttachedItemLink(oid,aid))
		end
		local tt = ItemTooltip.SetBuybackItem
		ItemTooltip.SetBuybackItem = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetBuybackItemLink(id))
		end
		local tt = ItemTooltip.SetTradingHouseItem
		ItemTooltip.SetTradingHouseItem = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetTradingHouseSearchResultItemLink(id))
		end
		local tt = ItemTooltip.SetTradingHouseListing
		ItemTooltip.SetTradingHouseListing = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetTradingHouseListingItemLink(id))
		end
		local tt = ItemTooltip.SetTradeItem
		ItemTooltip.SetTradeItem = function(c,_,slot,...)
			tt(c,_,slot,...)
			TooltipShow(c,GetTradeItemLink(slot))
		end
		local tt = ItemTooltip.SetQuestReward
		ItemTooltip.SetQuestReward = function(c,id,...)
			tt(c,id,...)
			TooltipShow(c,GetQuestRewardItemLink(id))
		end
	end

	return self
end

local EM, SM = EVENT_MANAGER, SCENE_MANAGER
local PLAYER = CraftStore:PLAYER()
local PANEL = CraftStore:PANEL()
local STYLE = CraftStore:STYLE()
local TT = CraftStore:TOOLTIP()
local cmdr = false

function CraftStore:ShowPanel()
	SM:ToggleTopLevel(CS4_Panel)
end

function CraftStore:Queue()
	if CraftStore.init then
		if IsControlKeyDown() and IsShiftKeyDown() and not IsUnitInCombat('player') and not cmdr then
			SM:ShowTopLevel(CS4_Commander)
			cmdr = true
		elseif not IsControlKeyDown() and not IsShiftKeyDown() and cmdr then
			SM:HideTopLevel(CS4_Commander)
			cmdr = false
		end
	end
end

EM:RegisterForEvent('CraftStore_AddonLoad',EVENT_ADD_ON_LOADED,function(eventCode,addOnName)
    if addOnName ~= 'CraftStore4' then return end
    EM:UnregisterForEvent('CraftStore_AddonLoad',EVENT_ADD_ON_LOADED)
	ZO_CreateStringId('SI_BINDING_NAME_SHOW_CS4_WINDOW','Toggle CraftStore4')
	SM:RegisterTopLevel(CS4_Panel,false)
	SM:RegisterTopLevel(CS4_Style,false)
	SM:RegisterTopLevel(CS4_Commander,false)
	EM:RegisterForEvent('CraftStore_PlayerUnLoad',EVENT_PLAYER_DEACTIVATED,function()
		EM:UnregisterForEvent('CraftStore_PlayerUnLoad',EVENT_PLAYER_DEACTIVATED)
		EM:UnregisterForEvent('CraftStore_PlayerLevel', EVENT_LEVEL_UPDATE)
		EM:UnregisterForEvent('CraftStore_PlayerLevel', EVENT_VETERAN_RANK_UPDATE)
		EM:UnregisterForEvent('CraftStore_SkillChanged', EVENT_NON_COMBAT_BONUS_CHANGED)
	end)
	EM:RegisterForEvent('CraftStore_PlayerLoad',EVENT_PLAYER_ACTIVATED,function()
		EM:UnregisterForEvent('CraftStore_PlayerLoad',EVENT_PLAYER_ACTIVATED)
		TT:TooltipHandler()
		PANEL:DrawMatrix()
		PLAYER:Init()
		PLAYER:GetPlayerResearch()
		PANEL:DrawScenes()
		STYLE:Init()
		CraftStore.init = true
		d('CraftStore 4.00')
	end)
	EM:RegisterForEvent('CraftStore_HideOnMove',EVENT_NEW_MOVEMENT_IN_UI_MODE, function()
		if CraftStore.account.option[1] then
			SM:HideTopLevel(CS4_Panel)
			SM:HideTopLevel(CS4_Style)
			-- SM:HideTopLevel(CS4_Sets)
			-- SM:HideTopLevel(CS4_Cook)
			-- SM:HideTopLevel(CS4_Rune)
			-- SM:HideTopLevel(CS4_Flask)
		end
	end)
	ZO_PreHookHandler(CS4_Panel,'OnShow', function()
		PLAYER:UpdatePlayerResearch()
	end)
	ZO_PreHookHandler(CS4_Panel,'OnHide', function()
		CS4_Players:SetHidden(true)
	end)
end)
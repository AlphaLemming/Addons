local EM, SM = EVENT_MANAGER, SCENE_MANAGER
local PLAYER = CraftStore:PLAYER()
local PANEL = CraftStore:PANEL()
local STYLE = CraftStore:STYLE()
local TT = CraftStore:TOOLTIP()

function CraftStore:ShowPanel()
	SM:ToggleTopLevel(CS4_Panel)
    if not CS4_Panel:IsHidden() then
	end
end

EM:RegisterForEvent('CraftStore_AddonLoad',EVENT_ADD_ON_LOADED,function(eventCode,addOnName)
    if addOnName ~= 'CraftStore4' then return end
    EM:UnregisterForEvent('CraftStore_AddonLoad',EVENT_ADD_ON_LOADED)
	ZO_CreateStringId('SI_BINDING_NAME_SHOW_CS4_WINDOW','Toggle CraftStore4')
	SM:RegisterTopLevel(CS4_Panel,false)
	SM:RegisterTopLevel(CS4_Style,false)
	EM:RegisterForEvent('CraftStore_PlayerLoad',EVENT_PLAYER_ACTIVATED,function()
		EM:UnregisterForEvent('CraftStore_PlayerLoad',EVENT_PLAYER_ACTIVATED)
		PLAYER:Init()
		STYLE:Init()
		PLAYER:GetPlayerResearch()
		d('CraftStore 4.00')
	end)
	PANEL:DrawMatrix()
	STYLE:DrawStyle()
	TT:TooltipHandler()
end)
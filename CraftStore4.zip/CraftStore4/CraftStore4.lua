local EM, SM = EVENT_MANAGER, SCENE_MANAGER
local cs_player = CraftStore:PLAYER()

function CraftStore:ShowPanel()
	SM:ToggleTopLevel(CS4_Panel)
    if not CS4_Panel:IsHidden() then
	end
end

EM:RegisterForEvent('CraftStore_AddonLoad',EVENT_ADD_ON_LOADED,function(eventCode,addOnName)
    if addOnName ~= CraftStore.name then return end
    EM:UnregisterForEvent('CraftStore_AddonLoad',EVENT_ADD_ON_LOADED)
	SM:RegisterTopLevel(CS4_Panel,false)
	cs_player:Init(1)
end)
local lmb,rmb,mmb = '|t16:16:CraftStore4/lmb.dds|t','|t16:16:CraftStore4/rmb.dds|t','|t16:16:CraftStore4/mmb.dds|t'
local i,o = GetString('SI_ITEMTRAITTYPE',ITEM_TRAIT_TYPE_ARMOR_INTRICATE),GetString('SI_ITEMTRAITTYPE',ITEM_TRAIT_TYPE_ARMOR_ORNATE)
local lang = GetCVar('language.2') or 'en'
local localisation = {
	de = {
		nobagspace = '|cFFAA33CraftStore:|r |cFF0000Nicht genügend Platz im Inventar!|r',
		noSlot = '|cFFAA33CraftStore:|r |cFF0000Kein freier Forschungsplatz!|r',
		activeCharOnly = '|cFFAA33CraftStore:|r |cFF0000Nur für den aktuellen Charakter und am Handwerkstisch anwendbar!|r',
		itemNotFound = '|cFFAA33CraftStore:|r |cFF0000Der Gegenstand ist nicht im aktuillen Inventar oder der Bank!|r',
		level = 'Stufe',
		rank = 'Rang',
		bank = 'Bank',
		craftbag = 'Handwerkstasche',
		unknown = 'unbekannt',
		known = 'Bekannt',
		bag = {nil,'Bank',nil,nil,'Handwerkstasche',nil},
		finishResearch = '<<C:1>> hat |c00FF00<<C:2>>|r |c00FF88(<<C:3>>)|r fertig erforscht.',
		finishMount = '<<C:1>> hat die Reitausbildung abgeschlossen.',
		finish12 = 'Der 12-Stunden-Countdown ist abgelaufen.',
		finish24 = 'Der 24-Stunden-Countdown ist abgelaufen.',
		itemsearch = 'Need Research-Item: <<1>> - Offers?',
		light = 'Leicht',
		medium = 'Mittel',
		heavy = 'Schwer',
		deleteChar = 'Diesen Charakter löschen!',
		bait = {'Köder für: Jedes Gewässer','Köder für: Trübes Wasser','Köder für: Flüsse','Köder für: Seen','Köder für: Ozeane'},
		potency = {'additiv','subtraktiv'},
		menu = 'Menü',
		refineAll = 'Alle Glyphen zerlegen',
		filter = {'Waffen','Leichte Rüstung','Mittlere Rüstung','Schwere Rüstung','Schmuck','Schmiedekunst','Schneiderei','Schreinerei','Verzauberkunst','Alchemie','Versorgung','Material','Stile','Rezepte','Trophäen','Verwendbares','PvP','Sonstiges'},
		filterAll = '- Alles -',
		filterBank = '- Bank -',
		filterCraftbag = '- Handwerkstasche -',
		commander = {'CraftStore Hauptfenster','CraftStore Stil-Übersicht','CraftStore Set-Übersicht','CraftStoreCook','CraftStoreRune','CraftStoreFlask','CraftStoreBags'},
		crafting = {
		'|cE8DFAF'..lmb..' Gewählte Menge (min. 1) herstellen|r',
		'|cE8DFAF'..rmb..' Maximum (max. 50) herstellen|r',
		'|cE8DFAF'..mmb..' Zum Favoriten |r|t16:16:CraftStore4/star.dds|t',
		'|cE8DFAF'..lmb..' Auswählen|r',
		'|cE8DFAF'..rmb..' Im Chat verlinken|r',
		'|cE8DFAF'..lmb..' Zutaten markieren|r',
		'|cE8DFAF'..lmb..' Glyphe zerlegen|r',
		},
		'|cE8DFAF'..lmb..' Alle nicht hergestellen Glyphen zerlegen\n'..rmb..' Alle verfügbaren Glyphen zerlegen|r', --9
		shrines = {
		[-1] = {'Magiergilde','Augvea - benutze ein Portal im Gebäude der Magiergilde'},
		[-2] = {'Kriegergilde','Erdschmiede - benutze ein Portal im Gebäude der Kriegergilde'},
		[0] = {'<<C:1>>','Der Wegschrein ist noch unbekannt...'},
		[1] = {'<<C:1>>','Klicken, um zum <<C:1>> zu reisen'},
		},
		glyph = {
		'Unbedeutende',
		'Minderwertige',
		'Mickrige',
		'Schwache',
		'Niedere',
		'Geringe',
		'Gemäßigte',
		'Durchschnittliche',
		'Starke',
		'Starke',
		'Größere',
		'Große',
		'Imposante',
		'Monumentale',
		'Prächtige',
		'Wahrlich Prächtige',
		}
	},
	en = {
		nobagspace = 'E|cFFAA33CraftStore:|r |cFF0000Nicht genügend Platz im Inventar!|r',
		noSlot = 'E|cFFAA33CraftStore:|r |cFF0000Kein freier Forschungsplatz!|r',
		level = 'EStufe',
		rank = 'ERang',
		bank = 'EBank',
		unknown = 'Eunbekannt',
		finishResearch = 'E<<C:1>> hat |c00FF00<<C:2>>|r |c00FF88(<<C:3>>)|r fertig erforscht.',
		finishMount = 'E<<C:1>> hat die Reitausbildung abgeschlossen.',
		finish12 = 'EDer 12-Stunden-Countdown ist abgelaufen.',
		finish24 = 'EDer 24-Stunden-Countdown ist abgelaufen.',
		itemsearch = 'ENeed Research-Item: <<1>> - Offers?',

	},
	fr = {
	}
}

function CraftStore:LANGUAGE()
	self = {}
	if lang ~= 'de' and lang ~= 'fr' and lang ~= 'en' then lang = 'en' end
	
	function self:Get(value) return localisation[lang][value] or 'No translation found...' end
	
	return self
end

-- glyph = {
-- 'trifling',
-- 'inferior',
-- 'petty',
-- 'slight',
-- 'minor',
-- 'lesser',
-- 'moderate',
-- 'average',
-- 'strong',
-- 'major',
-- 'greater',
-- 'grand',
-- 'splendid',
-- 'monumental',
-- 'superb',
-- 'truly superb',
-- }

-- glyph = {
-- 'insignifiant',
-- 'inférieur',
-- 'petit',
-- 'léger',
-- 'mineur',
-- 'inférieur',
-- 'modéré',
-- 'moyen',
-- 'fort',
-- 'majeur',
-- 'bon',
-- 'grandiose',
-- 'splendide',
-- 'monumental',
-- 'superbe',
-- 'vraiment superbe',
-- }	
function CraftStore:LANGUAGE()
	self = {}
	local lang = GetCVar('language.2') or 'en'
	if lang ~= 'de' and lang ~= 'fr' and lang ~= 'en' then lang = 'en' end
	local localisation = {
		de = {
			nobagspace = '|cFFAA33CraftStore:|r |cFF0000Nicht genügend Platz im Inventar!|r',
			noSlot = '|cFFAA33CraftStore:|r |cFF0000Kein freier Forschungsplatz!|r',
			level = 'Stufe',
			rank = 'Rang',
			bank = 'Bank',
			craftbag = 'Handwerkstasche',
			unknown = 'unbekannt',
			known = 'Bekannt',
			finishResearch = '<<C:1>> hat |c00FF00<<C:2>>|r |c00FF88(<<C:3>>)|r fertig erforscht.',
			finishMount = '<<C:1>> hat die Reitausbildung abgeschlossen.',
			finish12 = 'Der 12-Stunden-Countdown ist abgelaufen.',
			finish24 = 'Der 24-Stunden-Countdown ist abgelaufen.',
			itemsearch = 'Need Research-Item: <<1>> - Offers?',
			light = 'Leicht',
			medium = 'Mittel',
			heavy = 'Schwer',
			deleteChar = 'Diesen Charakter löschen!',
			bait = {'Köder für: Jedes Gewässer','Köder für: Trübes Wasser','Köder für: Flüsse','Köder für: Seen','Köder für: Ozeane'},
			potency = {'additiv','subtraktiv'},
			menu = 'Menü',
			commander = {'CraftStore Hauptfenster','CraftStore Stil-Übersicht','CraftStore Set-Übersicht','CraftStoreCook','CraftStoreRune','CraftStoreFlask'},

		},
		en = {
			nobagspace = 'E|cFFAA33CraftStore:|r |cFF0000Nicht genügend Platz im Inventar!|r',
			noSlot = 'E|cFFAA33CraftStore:|r |cFF0000Kein freier Forschungsplatz!|r',
			level = 'EStufe',
			rank = 'ERang',
			bank = 'EBank',
			unknown = 'Eunbekannt',
			finishResearch = 'E<<C:1>> hat |c00FF00<<C:2>>|r |c00FF88(<<C:3>>)|r fertig erforscht.',
			finishMount = 'E<<C:1>> hat die Reitausbildung abgeschlossen.',
			finish12 = 'EDer 12-Stunden-Countdown ist abgelaufen.',
			finish24 = 'EDer 24-Stunden-Countdown ist abgelaufen.',
			itemsearch = 'ENeed Research-Item: <<1>> - Offers?',
		},
		fr = {
		}
	}
	
	function self:Get(value) return localisation[lang][value] or 'No translation found...' end
	
	return self
end
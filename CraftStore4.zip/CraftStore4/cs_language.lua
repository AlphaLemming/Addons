function CraftStore:LANGUAGE()
	self = {}
	local lang = GetCVar('language.2') or 'en'
	if lang ~= 'de' and lang ~= 'fr' and lang ~= 'en' then lang = 'en' end
	local localisation = {
		de = {
			nobagspace = '|cFFAA33CraftStore:|r |cFF0000Nicht gen�gend Platz im Inventar!|r',
			noSlot = '|cFFAA33CraftStore:|r |cFF0000Kein freier Forschungsplatz!|r',
			level = 'Stufe',
			rank = 'Rang',
			bank = 'Bank',
			unknown = 'unbekannt',
			finishResearch = '<<C:1>> hat |c00FF00<<C:2>>|r |c00FF88(<<C:3>>)|r fertig erforscht.',
			finishMount = '<<C:1>> hat die Reitausbildung abgeschlossen.',
			finish12 = 'Der 12-Stunden-Countdown ist abgelaufen.',
			finish24 = 'Der 24-Stunden-Countdown ist abgelaufen.',
			itemsearch = 'Need Research-Item: <<1>> - Offers?',
		},
		en = {
			nobagspace = 'E|cFFAA33CraftStore:|r |cFF0000Nicht gen�gend Platz im Inventar!|r',
			noSlot = 'E|cFFAA33CraftStore:|r |cFF0000Kein freier Forschungsplatz!|r',
			level = 'EStufe',
			rank = 'ERang',
			bank = 'EBank',
			unknown = 'Eunbekannt',
			finishResearch = 'E<<C:1>> hat |c00FF00<<C:2>>|r |c00FF88(<<C:3>>)|r fertig erforscht.',
			finishMount = 'E<<C:1>> hat die Reitausbildung abgeschlossen.',
			finish12 = 'EDer 12-Stunden-Countdown ist abgelaufen.',
			finish24 = 'EDer 24-Stunden-Countdown ist abgelaufen.',
			itemsearch = 'ENeed Research-Item: <<1>> - Offers?',
		},
		fr = {
		}
	}
	
	function self:Get(value) return localisation[lang][value] or 'No translation found...' end
	
	return self
end
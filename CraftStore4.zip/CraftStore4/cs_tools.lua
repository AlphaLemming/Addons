local mass_filter = {
{1}, -- Weapons
{2,15,13}, -- Light Armor
{2,15,13}, -- Medium Armor
{2,15,13}, -- Heavy Armor
{2}, -- Jewelry
{23,24,35,36,41}, -- Blacksmithing
{24,39,40,43}, -- Clothier
{23,24,37,38,42}, -- Woodworking
{20,21,25,26,49,51,52,53}, -- Enchanting
{31,33,58}, -- Alchemy
{10,27,54}, -- Provisioning
{17,44,45,46}, -- Material
{8}, -- Styles
{29}, -- Reciepes
{5}, -- Trophies
{4,7,9,12,30}, -- Useables
{6,47}, -- PvP
{3,14,16,18,19,22,28,32,34,48,50,55,56,57} -- Misc
}

function CraftStore:TOOLS()
	self = {}
	local LANG = CraftStore:LANGUAGE()

	function self:spairs(t)
		local keys, i = {}, 0
		for k in pairs(t) do keys[#keys+1] = k end
		table.sort(keys,function(a,b) return a<b end)
		return function()
			i = i + 1
			if keys[i] then return keys[i], t[keys[i]] end
		end
	end
	
	function self:SplitLink(link,nr)
		local split = {SplitString(':', link)}
		if split[nr] then return tonumber(split[nr])
		elseif not nr and split then return split
		else return false end
	end

	function self:FlatLink(link)
		local split = {SplitString(':', link)}
		split[1] = '|H0'
		split[19] = 0
		split[20] = 0
		split[22] = 10000
		return tostring(table.concat(split,':'))
	end

	function self:ScanBagUID(uid)
		if not uid then return false end
		local bag = SHARED_INVENTORY:GenerateFullSlotData(nil,BAG_BACKPACK,BAG_BANK)
		for _, data in pairs(bag) do if uid == Id64ToString(GetItemUniqueId(data.bagId,data.slotIndex)) then return data.bagId, data.slotIndex end end
		return false
	end
	
	function self:ScanBag(id)
		if not id then return false end
		local bag = SHARED_INVENTORY:GenerateFullSlotData(nil,BAG_BACKPACK,BAG_BANK,BAG_VIRTUAL)
		for _, data in pairs(bag) do if id == self:SplitLink(GetItemLink(data.bagId,data.slotIndex),3) then return data.bagId, data.slotIndex end end
		return false
	end

	function self:TableConcat(t1,t2)
		for i=1,#t2 do t1[#t1+1] = t2[i] end
		return t1
	end

	function self:TabLen(t)
		local count = 0
		for _ in pairs(t) do count = count + 1 end
		return count
	end
	
	function self:TabCount(t)
		local count = 0
		for k,val in pairs(t) do count = count + val end
		return count
	end

	function self:Contains(t,key)
		for k,v in pairs(t) do if v == key then return true end end
		return false
	end

	function self:NilZero(val)
		if not val or val == 0 then return nil end
		return val
	end

	function self:CreateFilterList()
		local filters = {}
		filters[1] = {false,LANG:Get('filterAll')}
		for nr = 1,#mass_filter do filters[nr + 1] = {nr,LANG:Get('filter')[nr]} end
		return filters
	end

	-- function self:GetItemCount(bag,slot,id)
		-- local lookbag = SHARED_INVENTORY:GenerateFullSlotData(nil,bag)
		-- local stolen, stack = IsItemStolen(bag,slot), 0
		-- for _,data in pairs(lookbag) do
			-- if Id64ToString(data.uniqueId) == id and data.stolen == stolen then stack = stack + data.stackCount end
		-- end
		-- return stack
	-- end
	
	function self:StockSort()
		local loop, sorted, name, stack = 1, {}
		local filter, owner = CraftStore.account.filter[1] or false, CraftStore.account.filter[2] or false
		for link,data in pairs(CraftStore.account.stock) do
			local s1, s2, s3 = false, false, false
			local phrase = CS4_BagsSearch:GetText() or ''
			name = zo_strformat('<<C:1>>',GetItemLinkName(link))
			stack = data[owner] or self:TabCount(data)
			if phrase ~= '' and string.find(string.lower(name),string.lower(phrase)) then s1 = true
			elseif phrase == '' then s1 = true end
			if owner and data[owner] then s2 = true 
			elseif not owner then s2 = true end
			if filter then
				local at, it = GetItemLinkArmorType(link), self:Contains(mass_filter[filter],GetItemLinkItemType(link))
				if filter == 2 and at == ARMORTYPE_LIGHT and it then s3 = true
				elseif filter == 3 and at == ARMORTYPE_MEDIUM and it then s3 = true
				elseif filter == 4 and at == ARMORTYPE_HEAVY and it then s3 = true
				elseif filter == 5 and at == ARMORTYPE_NONE and it then s3 = true
				elseif (filter == 1 or filter > 5 ) and it then s3 = true end
			else s3 = true end
			if s1 and s2 and s3 then sorted[loop] = {name,link,stack}; loop = loop + 1 end
		end
		CS4_BagsSearch:SetText('')
		table.sort(sorted,function(a,b) return a[1] < b[1] end)
		return sorted
	end
	
	function self:CompareItem(link1,link2)
		if not link2 then return true end
		if GetItemLinkQuality(link1) < GetItemLinkQuality(link2) then return true end
		if GetItemLinkQuality(link1) > GetItemLinkQuality(link2) then return false end
		if GetItemLinkRequiredLevel(link1) < GetItemLinkRequiredLevel(link2) then return true end
		if GetItemLinkRequiredChampionPoints(link1) < GetItemLinkRequiredChampionPoints(link2) then return true end
		return false
	end

    function self:Quality(nr,a,hex)
		local quality = {[0]={0.65,0.65,0.65,a},[1]={1,1,1,a},[2]={0.17,0.77,0.05,a},[3]={0.22,0.57,1,a},[4]={0.62,0.18,0.96,a},[5]={0.80,0.66,0.10,a},[99]={1,0,0,1}}
		local qualityhex = {[0]='B3B3B3',[1]='FFFFFF',[2]='2DC50E',[3]='3A92FF',[4]='A02EF7',[5]='EECA2A',[99]='FF0000'}
	    if hex then return qualityhex[nr] else return quality[nr] end
    end

	function self:SetPoint(val)
		while true do  
			val, k = string.gsub(val,'^(-?%d+)(%d%d%d)','%1.%2')
			if k == 0 then return val end
		end
	end

	function self:GetTime(seconds)
		if seconds and seconds > 0 then
			local d = math.floor(seconds / 86400)
			local h = math.floor((seconds - d * 86400) / 3600)
			local m = math.floor((seconds - d * 86400 - h * 3600) / 60)
			local s = math.floor((seconds - d * 86400 - h * 3600 - m * 60))
			if d > 0 then return ('%ud %02u:%02u:%02u'):format(d,h,m,s)
			elseif h > 0 then return ('%02u:%02u:%02u'):format(h,m,s)
			else return ('%02u:%02u'):format(m,s) end
		else return '|t16:16:CraftStore4/tick.dds|t' end
	end

	function self:GetCharacters(filter)
		local oi = {}
		for key,_ in pairs(CraftStore.account.player) do table.insert(oi,key) end
		if filter then
			table.insert(oi,LANG:Get('filterAll'))
			table.insert(oi,LANG:Get('filterBank'))
			table.insert(oi,LANG:Get('filterCraftbag'))
		end
		table.sort(oi)
		return oi
	end

	function self:GetBonus(bonus,craft)
		local level = GetNonCombatBonus(bonus) or 1
		local _,rank = GetSkillLineInfo(GetCraftingSkillLineIndices(craft))
		return {rank, level, GetMaxSimultaneousSmithingResearch(craft) or 1}
	end

	function self:GetLineInfo(craft,line)
		local name, icon = GetSmithingResearchLineInfo(craft,line)
		local craftname = GetSkillLineInfo(GetCraftingSkillLineIndices(craft))
		return zo_strformat('<<C:1>>',craftname), zo_strformat('<<C:1>>',name), icon
	end

	function self:GetTraitInfo(craft,line,trait)
		local tid,desc = GetSmithingResearchLineTraitInfo(craft,line,trait)
		local _,name,icon = GetSmithingTraitItemInfo(tid + 1)
		return zo_strformat('<<C:1>>',name), GetString('SI_ITEMTRAITTYPE',tid), desc, icon
	end

	function self:ToChat(text) StartChatInput(CHAT_SYSTEM.textEntry:GetText()..text) end
	
	return self
end
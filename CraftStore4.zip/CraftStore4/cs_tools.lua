function CraftStore:TOOLS()
	self = {}

	function self:spairs(t)
		local keys, i = {}, 0
		for k in pairs(t) do keys[#keys+1] = k end
		table.sort(keys,function(a,b) return a<b end)
		return function()
			i = i + 1
			if keys[i] then return keys[i], t[keys[i]] end
		end
	end

	function self:SplitLink(link,nr)
		local split = {SplitString(':', link)}
		if split[nr] then return tonumber(split[nr]) else return false end
	end

	function self:CompareItem(link1,link2)
		if not link2 then return true end
		if GetItemLinkQuality(link1) < GetItemLinkQuality(link2) then return true end
		if GetItemLinkQuality(link1) > GetItemLinkQuality(link2) then return false end
		if GetItemLinkRequiredLevel(link1) < GetItemLinkRequiredLevel(link2) then return true end
		if GetItemLinkRequiredVeteranRank(link1) < GetItemLinkRequiredVeteranRank(link2) then return true end
		return false
	end

	function self:GetTime(seconds)
		if seconds and seconds > 0 then
			local d = math.floor(seconds / 86400)
			local h = math.floor((seconds - d * 86400) / 3600)
			local m = math.floor((seconds - d * 86400 - h * 3600) / 60)
			local s = math.floor((seconds - d * 86400 - h * 3600 - m * 60))
			if d > 0 then return ('%ud %02u:%02u:%02u'):format(d,h,m,s)
			else return ('%02u:%02u:%02u'):format(h,m,s) end
		else return '|t20:20:CraftStore4/tick.dds|t' end
	end

	function self:GetCharacters()
		local oi = {}
		for key,_ in pairs(CraftStore.account.player) do table.insert(oi,key) end
		table.sort(oi)
		return oi
	end

	function self:GetBonus(bonus,craft)
		local level = GetNonCombatBonus(bonus) or 1
		local _,rank = GetSkillLineInfo(GetCraftingSkillLineIndices(craft))
		return {rank, level, GetMaxSimultaneousSmithingResearch(craft) or 1}
	end

	function self:GetLineInfo(craft,line)
		local name, icon = GetSmithingResearchLineInfo(craft,line)
		local craftname = GetSkillLineInfo(GetCraftingSkillLineIndices(craft))
		return craftname, zo_strformat('<<C:1>>',name), icon
	end

	function self:GetTraitInfo(craft,line,trait)
		local tid,desc = GetSmithingResearchLineTraitInfo(craft,line,trait)
		local _,_,icon = GetSmithingTraitItemInfo(trait + 1)
		return GetString('SI_ITEMTRAITTYPE',tid), desc, icon
	end
	
	return self
end
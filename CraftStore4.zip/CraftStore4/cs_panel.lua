function CraftStore:PANEL()
	self = {}
	local WM = WINDOW_MANAGER
	local TT = CraftStore:TOOLTIP()
	local PLAYER = CraftStore:PLAYER()
	local TRAIT = CraftStore:TRAIT()
	local LANG = CraftStore:LANGUAGE()
	local TOOLS = CraftStore:TOOLS()
	local _,_,maxtrait = GetSmithingResearchLineInfo(1,1)
	
	local function SetResearch(craft,line,trait)
	end

	local function PostTrait(craft,line,trait)
		TOOLS:ToChat(zo_strformat(LANG:Get('itemsearch'),WM:GetControlByName('CS4_Craft'..craft..'Line'..line..'Trait'..trait).cs_data.trait))
	end
	
	local function SetActive(c,craft,line)
		local char = PLAYER:GetPlayer()
		for x = 1, c:GetNumChildren() do c:GetChild(x):ToggleHidden() end
		CraftStore.account.player[char].research[craft][line].active = not CraftStore.account.player[char].research[craft][line].active or true
	end

	local function SetAllActive(craft)
		for line = 1, GetNumSmithingResearchLines(craft) do
			local c = WM:GetControlByName('CS4_Craft'..craft..'Line'..line)
			if c then SetActive(c,craft,line) end
		end
	end
	
	local function DrawColumn(craft,line,parent,x)
		local craftname, name, icon = TOOLS:GetLineInfo(craft,line)
		local c = WM:CreateControl('CS4_Craft'..craft..'Line'..line, CS4_Panel, CT_BUTTON)
		c:SetAnchor(3,parent,3,x*30,0)
		c:SetDimensions(29,maxtrait*26+61)
		c:SetNormalTexture('CraftStore4/grey.dds')
		c:SetMouseOverTexture('CraftStore4/over.dds')
		c:SetClickSound('Click')
		c:EnableMouseButton(2,true)
		c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		c:SetHandler('OnMouseDown', function(self,button) if button == 1 then SetActive(self,craft,line) else SetAllActive(craft) end end)
		c.cs_data = { info = zo_strformat('|cFFFFFF<<1>>\n<<2>>',name,craftname), anchor = {c,3,9,2,0} }
		local x = WM:CreateControl('CS4_Craft'..craft..'Line'..line..'Texture', CS4_Panel, CT_TEXTURE)
		x:SetAnchor(1,c,1,0,2)
		x:SetDrawLayer(2)
		x:SetDimensions(27,27)
		x:SetTexture(icon)
		for trait = 1, maxtrait do
			local t = WM:CreateControl('$(parent)Trait'..trait, c, CT_BUTTON)
			t:SetAnchor(3,c,3,2,32+(trait-1)*26)
			t:SetDimensions(25,25)
			t:SetNormalTexture('CraftStore4/dark.dds')
			t:SetMouseOverTexture('CraftStore4/over.dds')
			t:SetClickSound('Click')
			t:EnableMouseButton(2,true)
			t:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
			t:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			t:SetHandler('OnMouseDown', function(self,button) if button == 1 then SetResearch(craft,line,trait) else PostTrait(craft,line,trait) end end)
		end
		local l = WM:CreateControl('$(parent)Count', c, CT_BUTTON)
		l:SetAnchor(4,c,4,0,-2)
		l:SetDrawLevel(2)
		l:SetDimensions(25,25)
		l:SetHorizontalAlignment(1)
		l:SetVerticalAlignment(1)
		l:SetFont('CS4Font')
		l:SetNormalFontColor(1,1,1,1)
		l:SetNormalTexture('CraftStore4/dark.dds')
		local x = WM:CreateControl('$(parent)DisabledTexture', c, CT_TEXTURE)
		x:SetAnchor(CENTER)
		x:SetDrawLayer(2)
		x:SetDimensions(21,21)
		x:SetTexture('CraftStore4/cross.dds')
		x:SetHidden(true)
	end

	local function DrawTraitRow(line,trait,nr,y)
		local c = WM:CreateControl('CS4_TraitRow'..trait, CS4_Panel, CT_BUTTON)
		local item, name, desc, icon = TOOLS:GetTraitInfo(CRAFTING_TYPE_BLACKSMITHING,line,nr)
		c:SetAnchor(3,CS4_Panel,3,10,y+(nr-1)*26)
		c:SetDimensions(153,25)
		c:SetText(name..' |t23:23:'..icon..'|t|t5:25:x.dds|t')
		c:SetHorizontalAlignment(2)
		c:SetVerticalAlignment(1)
		c:SetFont('CS4Font')
		c:SetNormalFontColor(1,1,1,1)
		c:SetMouseOverFontColor(1,0.66,0.2,1)
		c:SetNormalTexture('CraftStore4/grey.dds')
		c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		c.cs_data = { info = zo_strformat('|cFFFFFF<<C:1>>|r\n<<C:2>>',item,desc), anchor = {c,3,6,0,2} }
	end

	function self:DrawMatrix()
		for trait,nr in pairs(TRAIT:GetArmorTraits()) do DrawTraitRow(8,trait,nr,69) end
		for trait,nr in pairs(TRAIT:GetWeaponTraits()) do DrawTraitRow(1,trait,nr,369) end

		local c1 = CreateControl('CS4_ResearchBlock1', CS4_Panel, CT_CONTROL)
		c1:SetAnchor(3,CS4_TraitRow11,9,1,-31)
		c1:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 1, 7 do DrawColumn(CRAFTING_TYPE_CLOTHIER,line,c1,line-1) end

		local c2 = CreateControl('CS4_ResearchBlock2', CS4_Panel, CT_CONTROL)
		c2:SetAnchor(3,c1,9,5,0)
		c2:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 8, 14 do DrawColumn(CRAFTING_TYPE_CLOTHIER,line,c2,line-8) end
		
		local c3 = CreateControl('CS4_ResearchBlock3', CS4_Panel, CT_CONTROL)
		c3:SetAnchor(3,c2,9,5,0)
		c3:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 8, 14 do DrawColumn(CRAFTING_TYPE_BLACKSMITHING,line,c3,line-8) end

		local c4 = CreateControl('CS4_ResearchBlock4', CS4_Panel, CT_CONTROL)
		c4:SetAnchor(3,CS4_TraitRow1,9,1,-31)
		c4:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 1, 7 do DrawColumn(CRAFTING_TYPE_BLACKSMITHING,line,c4,line-1) end
		
		local c5 = CreateControl('CS4_ResearchBlock5', CS4_Panel, CT_CONTROL)
		c5:SetAnchor(3,c3,9,5,0)
		c5:SetDimensions(30,maxtrait*26+61)
		DrawColumn(CRAFTING_TYPE_WOODWORKING,6,c5,0)

		local c6 = CreateControl('CS4_ResearchBlock6', CS4_Panel, CT_CONTROL)
		c6:SetAnchor(3,c4,9,5,0)
		c6:SetDimensions(5*30-1,maxtrait*26+61)
		for line = 1, 5 do DrawColumn(CRAFTING_TYPE_WOODWORKING,line,c6,line-1) end
	end
	
	return self
end

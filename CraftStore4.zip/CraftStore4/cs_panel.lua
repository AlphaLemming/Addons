local WM, EM = WINDOW_MANAGER, EVENT_MANAGER
local maxtrait = 9

function CraftStore:PANEL()
	self = {}
	local PLAYER = CraftStore:PLAYER()
	local TRAIT = CraftStore:TRAIT()
	local LANG = CraftStore:LANGUAGE()
	local STYLE = CraftStore:STYLE()
	local TOOLS = CraftStore:TOOLS()
	local TT = CraftStore:TOOLTIP()
	
	local function SetResearch(craft,line,trait)
		if PLAYER:GetIsSelf(GetUnitName('player')) and GetCraftingInteractionType() == craft then
			local pos = craft..'&'..line..'&'..trait
			local store = CraftStore.account.stored[pos]
			if PLAYER:GetIsSelf(store.owner) or store.owner == LANG:Get('bank') then
				local uid = store.id or false
				if uid then
					local bag,slot = TOOLS:ScanBagUID(uid)
					if CanItemBeSmithingTraitResearched(bag,slot,craft,line,trait) then ResearchSmithingTrait(bag,slot) else d(LANG:Get('noSlot')) end
				end
			else d(LANG:Get('itemNotFound')) end
		else d(LANG:Get('activeCharOnly')) end
	end

	local function PostTrait(craft,line,trait)
		TOOLS:ToChat(zo_strformat(LANG:Get('itemsearch'),WM:GetControlByName('CS4_Craft'..craft..'Line'..line..'Trait'..trait).cs_data.trait))
	end
	
	local function SetActive(c,craft,line)
		local char = PLAYER:GetPlayer()
		for x = 1, c:GetNumChildren() do c:GetChild(x):ToggleHidden() end
		CraftStore.account.player[char].research[craft][line].active = not CraftStore.account.player[char].research[craft][line].active or true
	end

	local function SetAllActive(craft)
		for line = 1, GetNumSmithingResearchLines(craft) do
			local c = WM:GetControlByName('CS4_Craft'..craft..'Line'..line)
			if c then SetActive(c,craft,line) end
		end
	end

	local function DrawColumn(craft,line,parent,x)
		local craftname, name, icon = TOOLS:GetLineInfo(craft,line)
		local c = WM:CreateControl('CS4_Craft'..craft..'Line'..line, CS4_Panel, CT_BUTTON)
		c:SetAnchor(3,parent,3,x*30,0)
		c:SetDimensions(29,maxtrait*26+61)
		c:SetNormalTexture('CraftStore4/grey.dds')
		c:SetMouseOverTexture('CraftStore4/over.dds')
		c:SetClickSound('Click')
		c:EnableMouseButton(2,true)
		c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		c:SetHandler('OnMouseDown', function(self,button) if button == 1 then SetActive(self,craft,line) else SetAllActive(craft) end end)
		c.cs_data = { info = zo_strformat('|cFFFFFF<<1>>\n<<2>>',name,craftname), anchor = {c,3,9,2,0} }
		local x = WM:CreateControl('CS4_Craft'..craft..'Line'..line..'Texture', CS4_Panel, CT_TEXTURE)
		x:SetAnchor(1,c,1,0,2)
		x:SetDrawLayer(2)
		x:SetDimensions(27,27)
		x:SetTexture(icon)
		for trait = 1, maxtrait do
			local t = WM:CreateControl('$(parent)Trait'..trait, c, CT_BUTTON)
			t:SetAnchor(3,c,3,2,32+(trait-1)*26)
			t:SetDimensions(25,25)
			t:SetNormalTexture('CraftStore4/dark.dds')
			t:SetMouseOverTexture('CraftStore4/over.dds')
			t:SetClickSound('Click')
			t:EnableMouseButton(2,true)
			t:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
			t:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			t:SetHandler('OnMouseDown', function(self,button) if button == 1 then SetResearch(craft,line,trait) else PostTrait(craft,line,trait) end end)
		end
		local l = WM:CreateControl('$(parent)Count', c, CT_BUTTON)
		l:SetAnchor(4,c,4,0,-2)
		l:SetDrawLevel(2)
		l:SetDimensions(25,25)
		l:SetHorizontalAlignment(1)
		l:SetVerticalAlignment(1)
		l:SetFont('CS4Font')
		l:SetNormalFontColor(1,1,1,1)
		l:SetNormalTexture('CraftStore4/dark.dds')
		local x = WM:CreateControl('$(parent)DisabledTexture', c, CT_TEXTURE)
		x:SetAnchor(CENTER)
		x:SetDrawLayer(2)
		x:SetDimensions(21,21)
		x:SetTexture('CraftStore4/cross.dds')
		x:SetHidden(true)
	end

	local function DrawTraitRow(line,trait,nr,y)
		local c = WM:CreateControl('CS4_TraitRow'..trait, CS4_Panel, CT_BUTTON)
		local item, name, desc, icon = TOOLS:GetTraitInfo(CRAFTING_TYPE_BLACKSMITHING,line,nr)
		c:SetAnchor(3,CS4_Panel,3,10,y+(nr-1)*26)
		c:SetDimensions(153,25)
		c:SetText(name..' |t23:23:'..icon..'|t|t5:25:x.dds|t')
		c:SetHorizontalAlignment(2)
		c:SetVerticalAlignment(1)
		c:SetFont('CS4Font')
		c:SetNormalFontColor(1,1,1,1)
		c:SetMouseOverFontColor(1,0.66,0.2,1)
		c:SetNormalTexture('CraftStore4/grey.dds')
		c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		local bag, bank, cbag = GetItemLinkStacks(GetSmithingTraitItemLink(trait + 1))
		c.cs_data = { info = zo_strformat('|cFFFFFF<<C:1>> |t15:15:esoui/art/tooltips/icon_bag.dds|t '..(bag+bank+(cbag or 0))..'|r\n<<C:2>>',item,desc), anchor = {c,3,6,0,2} }
	end

	local function DrawStyles()
		local xpos, ypos = 0, 0
		for nr,tex in pairs(CraftStore.icons) do
			local c = WM:CreateControl('$(parent)Icon'..tex, CS4_Style, CT_BUTTON)
			c:SetAnchor(3,CS4_Style,3,10+xpos,199+ypos)
			c:SetDimensions(72,72)
			c:SetNormalTexture('CraftStore4/grey.dds')
			c:SetMouseOverTexture('CraftStore4/over.dds')
			c:EnableMouseButton(2,true)
			c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
			c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			c:SetHandler('OnMouseDown', function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) end end)
			local t = WM:CreateControl('$(parent)Texture', c, CT_TEXTURE)
			t:SetAnchor(128,c,128,0,0)
			t:SetDrawTier(2)
			t:SetDimensions(64,64)
			if nr%2 == 0 then ypos = ypos + 73 end
			if xpos == 0 then xpos = 73 else xpos = 0 end
		end
		ypos = 0
		local vals = {}
		for k in pairs(CraftStore.styles) do
			local _,_,_,_,rawStyle = GetSmithingStyleItemInfo(k)
			local name = zo_strformat('<<C:1>>',GetString('SI_ITEMSTYLE', rawStyle))
			table.insert(vals,{k,name})
		end
		table.sort(vals,function(a,b) return a[2] < b[2] end)
		for x = 1,#vals do
			c = WM:CreateControl('$(parent)Stylename'..vals[x][1], CS4_StyleListScrollChild, CT_BUTTON)
			c:SetAnchor(3,CS4_StyleListScrollChild,3,7,ypos)
			c:SetDimensions(280,25)
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetClickSound('Click')
			c:SetFont('CS4Font')
			c:SetNormalFontColor(1,1,1,1)
			c:SetMouseOverFontColor(1,0.66,0.2,1)
			c:SetHandler('OnClicked', function() CraftStore.character.style_active = vals[x][1]; STYLE:SetActiveStyle(); MarkSelected(5) end)
			c.style = vals[x][1]
			ypos = ypos + 25
		end
		CS4_StyleListScrollChild:SetHeight(ypos+5)
		CS4_StyleStyleitem:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		CS4_StyleStyleitem:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		CS4_StyleStyleitem:SetHandler('OnMouseDown', function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) end end)
		CS4_StyleHeaderAchieve:SetHandler('OnMouseDown',function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) else ACHIEVEMENTS:ShowAchievementPopup(unpack(self.cs_data.popup)); ZO_PopupTooltip_Hide() end end)
		CS4_StyleArmor1:SetText(LANG:Get('light'))
		CS4_StyleArmor1:SetHandler('OnClicked',function() CraftStore.character.style_armor = 1; STYLE:SetActiveStyle(); MarkSelected(4) end)
		CS4_StyleArmor2:SetText(LANG:Get('medium'))
		CS4_StyleArmor2:SetHandler('OnClicked',function() CraftStore.character.style_armor = 2; STYLE:SetActiveStyle(); MarkSelected(4) end)
		CS4_StyleArmor3:SetText(LANG:Get('heavy'))
		CS4_StyleArmor3:SetHandler('OnClicked',function() CraftStore.character.style_armor = 3; STYLE:SetActiveStyle(); MarkSelected(4) end)
	end

	local function Slide(c,h)
		local a = ANIMATION_MANAGER:CreateTimeline()
		local fade = a:InsertAnimation(ANIMATION_ALPHA,c)
		local grow = a:InsertAnimation(ANIMATION_SIZE,c)
		fade:SetDuration(150)
		grow:SetDuration(150)
		grow:SetEasingFunction(ZO_GenerateCubicBezierEase(.25,.5,.4,1.2))
		grow:SetStartAndEndHeight(h,h)
		if c:IsHidden() then
			c:SetHidden(false)
			fade:SetAlphaValues(0,1)
			grow:SetStartAndEndWidth(0,240)
		else
			fade:SetAlphaValues(1,0)
			grow:SetStartAndEndWidth(240,0)
			a:SetHandler('OnStop', function() c:SetHidden(true) end)
		end
		a:PlayFromStart()
	end

	local function DrawPlayer()
		local count = 0
		for nr,player in pairs(TOOLS:GetCharacters()) do
			local c = WM:GetControlByName('CS4_PlayersListScrollChildPlayer'..nr)
			if not c then
				c = WM:CreateControl('$(parent)Player'..nr, CS4_PlayersListScrollChild, CT_BUTTON)
				c:SetAnchor(3,CS4_PlayersListScrollChild,3,0,(nr-1)*31)
				c:SetDimensions(240,30)
				c:SetNormalTexture('CraftStore4/grey.dds')
				c:SetMouseOverTexture('CraftStore4/over.dds')
				c:SetHorizontalAlignment(0)
				c:SetVerticalAlignment(1)
				c:SetClickSound('Click')
				c:SetFont('CS4Font')
				c:SetNormalFontColor(1,1,1,1)
				c:SetMouseOverFontColor(1,0.66,0.2,1)
				c:SetHandler('OnMouseEnter', function(self) self:GetNamedChild('Ereaser'):SetHidden(false) end)
				c:SetHandler('OnMouseExit', function(self) self:GetNamedChild('Ereaser'):SetHidden(true) end)
				c:SetHandler('OnClicked', function()
					PLAYER:SetPlayer(player)
					PLAYER:GetPlayerResearch()
					STYLE:SetActiveStyle()
					MarkSelected(1)
				end)
				local e = WM:CreateControl('$(parent)Ereaser', c, CT_BUTTON)
				e:SetAnchor(8,c,8,-24,0)
				e:SetDimensions(16,16)
				e:SetNormalTexture('CraftStore4/cross.dds')
				e:SetMouseOverTexture('CraftStore4/over.dds')
				e:SetHidden(true)
				e:SetClickSound('Click')
				e:SetHandler('OnMouseEnter', function(self) self:SetHidden(false); TT:ShowTooltip(self) end)
				e:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
				e:SetHandler('OnClicked', function() PLAYER:DeletePlayer(player); DrawPlayer() end)
				e.cs_data = { info = LANG:Get('deleteChar'), anchor = {e,1,4,0,2} }
			end
			c:SetText('|t8:5:x.dds|t'..player)
			c.name = player
			count = count + 1
		end
		CS4_PlayersListScrollChild:SetDimensions(240,count*31)
	end
	
	local function DrawPlayerFilter()
		local count, players = 0, {
			LANG:Get('filterAll'),
			LANG:Get('filterBank'),
			LANG:Get('filterCraftbag')
		}
		for _,player in pairs(TOOLS:GetCharacters()) do table.insert(players,player) end
		for nr,player in pairs(players) do
			local c = WM:CreateControl('$(parent)Player'..nr, CS4_FilterPlayerScrollChild, CT_BUTTON)
			c:SetAnchor(3,CS4_FilterPlayerScrollChild,3,0,(nr-1)*31)
			c:SetDimensions(240,30)
			c:SetNormalTexture('CraftStore4/grey.dds')
			c:SetMouseOverTexture('CraftStore4/over.dds')
			c:SetText('|t8:5:x.dds|t'..player)
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetClickSound('Click')
			c:SetFont('CS4Font')
			c:SetNormalFontColor(1,1,1,1)
			c:SetMouseOverFontColor(1,0.66,0.2,1)
			c:SetHandler('OnClicked', function()
				if nr == 1 then CraftStore.account.filter[2] = false
				elseif nr == 2 then CraftStore.account.filter[2] = 'aa'
				elseif nr == 3 then CraftStore.account.filter[2] = 'ab'
				else CraftStore.account.filter[2] = player end
				DrawBags()
				MarkSelected(2)
			end)
			if nr == 1 then c.name = false elseif nr == 2 then c.name = 'aa'
			elseif nr == 3 then c.name = 'ab' else c.name = player end
			count = count + 1
		end
		CS4_FilterPlayerScrollChild:SetDimensions(240,count*31+60)
	end
	
	function MarkSelected(btn)
		if btn == 1 then
			for nr = 1, CS4_PlayersListScrollChild:GetNumChildren() do
				local c = CS4_PlayersListScrollChild:GetNamedChild('Player'..nr)
				if PLAYER:GetPlayer() == c.name then
					c:SetNormalFontColor(1,0.66,0.2,1)
				else
					c:SetNormalFontColor(1,1,1,1)
				end
			end
		elseif btn == 2 then
			for nr = 1, CS4_FilterPlayerScrollChild:GetNumChildren() do
				local c = CS4_FilterPlayerScrollChild:GetChild(nr)
				if CraftStore.account.filter[2] == c.name then
					c:SetNormalFontColor(1,0.66,0.2,1)
				else
					c:SetNormalFontColor(1,1,1,1)
				end
			end
		elseif btn == 3 then
			for nr = 1, CS4_FilterFiltersScrollChild:GetNumChildren() do
				local c = CS4_FilterFiltersScrollChild:GetChild(nr)
				if CraftStore.account.filter[1] == c.filter then
					c:SetNormalFontColor(1,0.66,0.2,1)
				else
					c:SetNormalFontColor(1,1,1,1)
				end
			end
		elseif btn == 4 then
			for nr = 1, 3 do
				local c = WM:GetControlByName('CS4_StyleArmor'..nr)
				if CraftStore.character.style_armor == nr then
					c:SetNormalFontColor(1,0.66,0.2,1)
				else
					c:SetNormalFontColor(1,1,1,1)
				end
			end
		elseif btn == 5 then
			for nr = 1, CS4_StyleListScrollChild:GetNumChildren() do
				local c = CS4_StyleListScrollChild:GetChild(nr)
				if CraftStore.character.style_active == c.style then
					c:SetNormalFontColor(1,0.66,0.2,1)
				else
					c:SetNormalFontColor(1,1,1,1)
				end
			end
		end
	end

	function self:DrawMatrix()
		for trait,nr in pairs(TRAIT:GetArmorTraits()) do DrawTraitRow(8,trait,nr,69) end
		for trait,nr in pairs(TRAIT:GetWeaponTraits()) do DrawTraitRow(1,trait,nr,369) end

		local c1 = CreateControl('CS4_ResearchBlock1', CS4_Panel, CT_CONTROL)
		c1:SetAnchor(3,CS4_TraitRow11,9,1,-31)
		c1:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 1, 7 do DrawColumn(CRAFTING_TYPE_CLOTHIER,line,c1,line-1) end

		local c2 = CreateControl('CS4_ResearchBlock2', CS4_Panel, CT_CONTROL)
		c2:SetAnchor(3,c1,9,5,0)
		c2:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 8, 14 do DrawColumn(CRAFTING_TYPE_CLOTHIER,line,c2,line-8) end
		
		local c3 = CreateControl('CS4_ResearchBlock3', CS4_Panel, CT_CONTROL)
		c3:SetAnchor(3,c2,9,5,0)
		c3:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 8, 14 do DrawColumn(CRAFTING_TYPE_BLACKSMITHING,line,c3,line-8) end

		local c4 = CreateControl('CS4_ResearchBlock4', CS4_Panel, CT_CONTROL)
		c4:SetAnchor(3,CS4_TraitRow1,9,1,-31)
		c4:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 1, 7 do DrawColumn(CRAFTING_TYPE_BLACKSMITHING,line,c4,line-1) end
		
		local c5 = CreateControl('CS4_ResearchBlock5', CS4_Panel, CT_CONTROL)
		c5:SetAnchor(3,c3,9,5,0)
		c5:SetDimensions(30,maxtrait*26+61)
		DrawColumn(CRAFTING_TYPE_WOODWORKING,6,c5,0)

		local c6 = CreateControl('CS4_ResearchBlock6', CS4_Panel, CT_CONTROL)
		c6:SetAnchor(3,c4,9,5,0)
		c6:SetDimensions(5*30-1,maxtrait*26+61)
		for line = 1, 5 do DrawColumn(CRAFTING_TYPE_WOODWORKING,line,c6,line-1) end
	end
	
	function DrawBags()
		local xpos, ypos, link = 0, 0
		for x = 1, CS4_BagsListScrollChild:GetNumChildren() do CS4_BagsListScrollChild:GetChild(x):SetHidden(true) end
		for slot,data in pairs(TOOLS:StockSort()) do
			link = data[2]
			local c = WM:GetControlByName('CS4_BagsListScrollChildSlot'..slot)
			local x = WM:GetControlByName('CS4_BagsListScrollChildSlot'..slot..'Texture')
			local l = WM:GetControlByName('CS4_BagsListScrollChildSlot'..slot..'Stack')
			if not c then
				c = WM:CreateControl('$(parent)Slot'..slot, CS4_BagsListScrollChild, CT_BUTTON)
				c:SetAnchor(3,CS4_BagsListScrollChild,3,xpos,ypos)
				c:SetDimensions(50,50)
				c:SetMouseOverTexture('CraftStore4/over.dds')
				c:EnableMouseButton(2,true)
				c:EnableMouseButton(3,true)
				c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self); TT:TTShow(c.tt,self.cs_data.link,nil) end)
				c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
				c:SetHandler('OnMouseDown', function(self,button)
					if button == 2 then TOOLS:ToChat(self.cs_data.link)
					elseif button == 3 then CraftStore.account.stock[self.cs_data.link] = nil; DrawBags() end
				end)
				x = WM:CreateControl('$(parent)Texture', c, CT_TEXTURE)
				x:SetAnchor(CENTER)
				x:SetDrawLayer(2)
				x:SetDimensions(46,46)
				l = WM:CreateControl('$(parent)Stack', c, CT_LABEL)
				l:SetAnchor(12,c,12,-5,-1)
				l:SetDrawLayer(3)
				l:SetHorizontalAlignment(2)
				l:SetVerticalAlignment(1)
				l:SetFont('ZoFontGameSmall')
				l:SetColor(1,1,1,1)
			end
			xpos = xpos + 51
			if xpos >= 408 then ypos = ypos + 51; xpos = 0 end
			c:SetNormalTexture('CraftStore4/q'..GetItemLinkQuality(link)..'.dds')
			c:SetHidden(false)
			c.cs_data = { link = link, anchor = {CS4_Filter,2,8,1,0} }
			x:SetTexture(GetItemLinkInfo(link))
			l:SetText(data[3])
			l:SetHidden(data[3] <= 1)
		end
		CS4_BagsListScrollChild:SetHeight(ypos+51)
	end
	
	function self:DrawBagsExtern() DrawBags() end
	function self:DrawStylesExtern() DrawStyles() end
	
	function self:DrawScenes()
		DrawStyles()
		DrawPlayer()
		CS4_PanelMenu:SetText('|t14:14:CraftStore4/menu.dds|t '..LANG:Get('menu'))
		CS4_PanelSign1:SetText(GetString(SI_ITEMTYPE2)..'|t10:5:x.dds|t')
		CS4_PanelSign2:SetText(LANG:Get('known')..'|t10:5:x.dds|t')
		CS4_PanelSign3:SetText(GetString(SI_ITEMTYPE1)..'|t10:5:x.dds|t')
		CS4_PanelSign4:SetText(LANG:Get('known')..'|t10:5:x.dds|t')
		CS4_CommanderButton1:SetText(LANG:Get('commander')[1])
		CS4_CommanderButton2:SetText(LANG:Get('commander')[2])
		CS4_CommanderButton3:SetText(LANG:Get('commander')[3])
		CS4_CommanderButton4:SetText(LANG:Get('commander')[4])
		CS4_CommanderButton5:SetText(LANG:Get('commander')[5])
		CS4_CommanderButton6:SetText(LANG:Get('commander')[6])
		CS4_CommanderButton7:SetText(LANG:Get('commander')[7])
		CS4_PlayersCloseButton:SetHandler('OnClicked', function() Slide(CS4_Players,690) end)
		CS4_PanelPlayer:SetHandler('OnClicked', function() Slide(CS4_Players,690) end)
		CS4_PanelPlayer:SetText(PLAYER:GetPlayer())
		CS4_BagsSource:SetHandler('OnClicked', function() Slide(CS4_Filter,639) end)
		CS4_BagsSearch:SetHandler('OnFocusLost', function() DrawBags() end)
		local crafting = {CRAFTING_TYPE_BLACKSMITHING, CRAFTING_TYPE_CLOTHIER, CRAFTING_TYPE_WOODWORKING}
		for _,craft in pairs(crafting) do
			for x = 1,3 do
				c = WM:GetControlByName('CS4_Research'..craft..'Line'..x)
				c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
				c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			end			
		end
		CS4_Panel:SetAnchor(3,Gui_Root,3,CraftStore.account.position[1][1],CraftStore.account.position[1][2])
		CS4_Style:SetAnchor(3,Gui_Root,3,CraftStore.account.position[2][1],CraftStore.account.position[2][2])
		CS4_SetCraft:SetAnchor(3,Gui_Root,3,CraftStore.account.position[3][1],CraftStore.account.position[3][2])
		CS4_Bags:SetAnchor(3,Gui_Root,3,CraftStore.account.position[4][1],CraftStore.account.position[4][2])
		CS4_BagsList.useFadeGradient = false
		for nr,data in pairs(TOOLS:CreateFilterList()) do
			local c = WM:CreateControl('$(parent)Filter'..nr, CS4_FilterFiltersScrollChild, CT_BUTTON)
			c:SetAnchor(3,CS4_FilterFiltersScrollChild,3,0,(nr-1)*31)
			c:SetDimensions(240,30)
			c:SetNormalTexture('CraftStore4/grey.dds')
			c:SetMouseOverTexture('CraftStore4/over.dds')
			c:SetText('|t8:5:x.dds|t'..data[2])
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetClickSound('Click')
			c:SetFont('CS4Font')
			c:SetNormalFontColor(1,1,1,1)
			c:SetMouseOverFontColor(1,0.66,0.2,1)
			-- c:SetHandler('OnMouseEnter', function(self) self:GetNamedChild('Ereaser'):SetHidden(false) end)
			-- c:SetHandler('OnMouseExit', function(self) self:GetNamedChild('Ereaser'):SetHidden(true) end)
			c:SetHandler('OnClicked', function()
				CraftStore.account.filter[1] = data[1]
				DrawBags()
				MarkSelected(3)
			end)
			c.filter = data[1]
			CS4_FilterFiltersScrollChild:SetHeight(nr*31)
		end
		local temp1,temp2 = unpack(CraftStore.account.filter)
		CraftStore.account.filter = {false,false}
		DrawBags()
		DrawPlayerFilter()
		CraftStore.account.filter = {temp1,temp2}
		MarkSelected(1)
		MarkSelected(2)
		MarkSelected(3)
		MarkSelected(4)
		MarkSelected(5)
		for g = 1,5 do
			local gid = GetGuildId(g)
			if gid then
				local c = WM:GetControlByName('CS4_BankSelector'..g)
				c:SetHandler('OnClicked',function()
					SelectGuildBank(gid)
					CraftStore.account.guild = gid
				end)
				c:SetText(GetGuildName(gid))
				c:SetHidden(false)
			end
		end
		local xpos, ypos = 0, 0
		for _,craft in pairs(crafting) do
			for line = 1, GetNumSmithingResearchLines(craft) do
				local craftname, name, icon = TOOLS:GetLineInfo(craft,line)
				local c = WM:CreateControl('$(parent)Icon'..craft..'&'..line,CS4_SetCraftTraitinfo,CT_BUTTON)
				c.cs_data = { str = '|cFFFFFF'..craftname..'|r\n'..name, anchor = {c,1,4,0,2} }
				c:SetAnchor(3,CS4_SetCraftTraitinfo,3,xpos,ypos)
				c:SetDimensions(32,32)
				c:SetNormalTexture('CraftStore4/grey.dds')
				c:SetMouseOverTexture('CraftStore4/over.dds')
				c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
				c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
				local t = WM:CreateControl('$(parent)Texture',c,CT_TEXTURE)
				t:SetAnchor(128,c,128,0,0)
				t:SetDimensions(28,28)
				t:SetTexture(icon)
				t:SetDrawTier(2)
				xpos = xpos + 33
				if xpos == 231 then xpos = 0; ypos = ypos + 33 end
			end
		end
		for nr,set in pairs(CraftStore.sets) do
			local link = '|H1:item:'..set.item..':370:50:0:370:50:0:0:0:0:0:0:0:0:0:28:0:0:0:10000:0|h|h'
			local _,setName = GetItemLinkSetInfo(link,false)
			local c = WM:CreateControl('$(parent)Set'..nr,CS4_SetCraftListScrollChild,CT_BUTTON)
			c:SetAnchor(3,CS4_SetCraftListScrollChild,3,5,3+(nr-1)*25)
			c:SetDimensions(240,25)
			c:EnableMouseButton(2,true)
			c:SetText('|t8:5:x.dds|t'..zo_strformat('[<<1>>] <<C:2>>',set.traits,setName))
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetClickSound('Click')
			c:SetFont('CS4Font')
			c:SetNormalFontColor(1,1,1,1)
			c:SetMouseOverFontColor(1,0.66,0.2,1)
			c:SetHandler('OnMouseDown', function(self,button)
				if button == 1 then PLAYER:UpdateSet(nr) else TOOLS:ToChat(self.cs_data.link) end
			end)
			c.cs_data = { link = link }
		end
		CS4_SetCraftListScrollChild:SetHeight(#CraftStore.sets * 25 + 5)
		CS4_SetCraftInfo.useFadeGradient = false
		for x = 1,3 do
			local c = WM:GetControlByName('CS4_SetCraftShrine'..x)
			c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
			c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		end
		PLAYER:UpdateSet(1)
	end
	
	return self
end

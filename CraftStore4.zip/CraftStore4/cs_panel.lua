function CraftStore:PANEL()
	self = {}
	local WM = WINDOW_MANAGER
	local PLAYER = CraftStore:PLAYER()
	local TRAIT = CraftStore:TRAIT()
	local LANG = CraftStore:LANGUAGE()
	local STYLE = CraftStore:STYLE()
	local TOOLS = CraftStore:TOOLS()
	local TT = CraftStore:TOOLTIP()
	local _,_,maxtrait = GetSmithingResearchLineInfo(1,1)
	
	local function SetResearch(craft,line,trait)
	end

	local function PostTrait(craft,line,trait)
		TOOLS:ToChat(zo_strformat(LANG:Get('itemsearch'),WM:GetControlByName('CS4_Craft'..craft..'Line'..line..'Trait'..trait).cs_data.trait))
	end
	
	local function SetActive(c,craft,line)
		local char = PLAYER:GetPlayer()
		for x = 1, c:GetNumChildren() do c:GetChild(x):ToggleHidden() end
		CraftStore.account.player[char].research[craft][line].active = not CraftStore.account.player[char].research[craft][line].active or true
	end

	local function SetAllActive(craft)
		for line = 1, GetNumSmithingResearchLines(craft) do
			local c = WM:GetControlByName('CS4_Craft'..craft..'Line'..line)
			if c then SetActive(c,craft,line) end
		end
	end
	
	local function DrawColumn(craft,line,parent,x)
		local craftname, name, icon = TOOLS:GetLineInfo(craft,line)
		local c = WM:CreateControl('CS4_Craft'..craft..'Line'..line, CS4_Panel, CT_BUTTON)
		c:SetAnchor(3,parent,3,x*30,0)
		c:SetDimensions(29,maxtrait*26+61)
		c:SetNormalTexture('CraftStore4/grey.dds')
		c:SetMouseOverTexture('CraftStore4/over.dds')
		c:SetClickSound('Click')
		c:EnableMouseButton(2,true)
		c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		c:SetHandler('OnMouseDown', function(self,button) if button == 1 then SetActive(self,craft,line) else SetAllActive(craft) end end)
		c.cs_data = { info = zo_strformat('|cFFFFFF<<1>>\n<<2>>',name,craftname), anchor = {c,3,9,2,0} }
		local x = WM:CreateControl('CS4_Craft'..craft..'Line'..line..'Texture', CS4_Panel, CT_TEXTURE)
		x:SetAnchor(1,c,1,0,2)
		x:SetDrawLayer(2)
		x:SetDimensions(27,27)
		x:SetTexture(icon)
		for trait = 1, maxtrait do
			local t = WM:CreateControl('$(parent)Trait'..trait, c, CT_BUTTON)
			t:SetAnchor(3,c,3,2,32+(trait-1)*26)
			t:SetDimensions(25,25)
			t:SetNormalTexture('CraftStore4/dark.dds')
			t:SetMouseOverTexture('CraftStore4/over.dds')
			t:SetClickSound('Click')
			t:EnableMouseButton(2,true)
			t:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
			t:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			t:SetHandler('OnMouseDown', function(self,button) if button == 1 then SetResearch(craft,line,trait) else PostTrait(craft,line,trait) end end)
		end
		local l = WM:CreateControl('$(parent)Count', c, CT_BUTTON)
		l:SetAnchor(4,c,4,0,-2)
		l:SetDrawLevel(2)
		l:SetDimensions(25,25)
		l:SetHorizontalAlignment(1)
		l:SetVerticalAlignment(1)
		l:SetFont('CS4Font')
		l:SetNormalFontColor(1,1,1,1)
		l:SetNormalTexture('CraftStore4/dark.dds')
		local x = WM:CreateControl('$(parent)DisabledTexture', c, CT_TEXTURE)
		x:SetAnchor(CENTER)
		x:SetDrawLayer(2)
		x:SetDimensions(21,21)
		x:SetTexture('CraftStore4/cross.dds')
		x:SetHidden(true)
	end

	local function DrawTraitRow(line,trait,nr,y)
		local c = WM:CreateControl('CS4_TraitRow'..trait, CS4_Panel, CT_BUTTON)
		local item, name, desc, icon = TOOLS:GetTraitInfo(CRAFTING_TYPE_BLACKSMITHING,line,nr)
		c:SetAnchor(3,CS4_Panel,3,10,y+(nr-1)*26)
		c:SetDimensions(153,25)
		c:SetText(name..' |t23:23:'..icon..'|t|t5:25:x.dds|t')
		c:SetHorizontalAlignment(2)
		c:SetVerticalAlignment(1)
		c:SetFont('CS4Font')
		c:SetNormalFontColor(1,1,1,1)
		c:SetMouseOverFontColor(1,0.66,0.2,1)
		c:SetNormalTexture('CraftStore4/grey.dds')
		c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		c.cs_data = { info = zo_strformat('|cFFFFFF<<C:1>>|r\n<<C:2>>',item,desc), anchor = {c,3,6,0,2} }
	end

	local function DrawStyles()
		local xpos, ypos = 0, 0
		for nr,tex in pairs(CraftStore.icons) do
			local c = WM:CreateControl('$(parent)Icon'..tex, CS4_Style, CT_BUTTON)
			c:SetAnchor(3,CS4_Style,3,10+xpos,194+ypos)
			c:SetDimensions(72,72)
			c:SetNormalTexture('CraftStore4/grey.dds')
			c:EnableMouseButton(2,true)
			c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
			c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			c:SetHandler('OnMouseDown', function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) end end)
			local t = WM:CreateControl('$(parent)Texture', c, CT_TEXTURE)
			t:SetAnchor(128,c,128,0,0)
			t:SetDrawTier(2)
			t:SetDimensions(64,64)
			if nr%2 == 0 then ypos = ypos + 73 end
			if xpos == 0 then xpos = 73 else xpos = 0 end
		end
		ypos = 0
		local vals, i = {}, 0
		for k in pairs(CraftStore.styles) do
			local _,_,_,_,rawStyle = GetSmithingStyleItemInfo(k)
			local name = zo_strformat('<<C:1>>',GetString('SI_ITEMSTYLE', rawStyle))
			table.insert(vals,{k,name})
		end
		table.sort(vals,function(a,b) return a[2] < b[2] end)
		for x = 1,#vals do
			c = WM:CreateControl('$(parent)Stylename'..vals[x][1], CS4_StyleListScrollChild, CT_BUTTON)
			c:SetAnchor(3,CS4_StyleListScrollChild,3,7,ypos)
			c:SetDimensions(280,25)
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetClickSound('Click')
			c:SetFont('CSFont')
			c:SetNormalFontColor(1,1,1,1)
			c:SetMouseOverFontColor(1,0.66,0.2,1)
			c:SetHandler('OnClicked', function() CraftStore.character.style_active = vals[x][1]; STYLE:SetActiveStyle() end)
			ypos = ypos + 25
		end
		CS4_StyleListScrollChild:SetHeight(ypos+5)
		CS4_StyleStyleitem:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
		CS4_StyleStyleitem:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
		CS4_StyleStyleitem:SetHandler('OnMouseDown', function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) end end)
		CS4_StyleHeaderAchieve:SetHandler('OnMouseDown',function(self,button) if button == 2 then TOOLS:ToChat(self.cs_data.link) else ACHIEVEMENTS:ShowAchievementPopup(unpack(self.cs_data.popup)); ZO_PopupTooltip_Hide() end end)
		CS4_StyleLight:SetText(LANG:Get('light'))
		CS4_StyleLight:SetHandler('OnClicked',function() CraftStore.character.style_armor = 1; STYLE:SetActiveStyle() end)
		CS4_StyleMedium:SetText(LANG:Get('medium'))
		CS4_StyleMedium:SetHandler('OnClicked',function() CraftStore.character.style_armor = 2; STYLE:SetActiveStyle() end)
		CS4_StyleHeavy:SetText(LANG:Get('heavy'))
		CS4_StyleHeavy:SetHandler('OnClicked',function() CraftStore.character.style_armor = 3; STYLE:SetActiveStyle() end)
	end

	local function FadePlayers(dir)
		if dir == 1 and not CS4_Players:IsHidden() then dir = 2 end
		local c, size = CS4_Players, 240
		local a = ANIMATION_MANAGER:CreateTimeline()
		local fade = a:InsertAnimation(ANIMATION_ALPHA,c)
		local grow = a:InsertAnimation(ANIMATION_SIZE,c)
		fade:SetDuration(150)
		grow:SetDuration(150)
		grow:SetEasingFunction(ZO_GenerateCubicBezierEase(.25,.5,.4,1.2))
		if dir == 1 then
			c:SetAlpha(0)
			c:SetHidden(false)
			fade:SetAlphaValues(0,1)
			grow:SetStartAndEndHeight(690,690)
			grow:SetStartAndEndWidth(0,size)
		elseif dir == 2 then
			fade:SetAlphaValues(1,0)
			grow:SetStartAndEndHeight(690,690)
			grow:SetStartAndEndWidth(size,0)
			a:SetHandler('OnStop', function() c:SetHidden(true) end)
		end
		a:PlayFromStart()
	end

	local function DrawPlayer()
		local count = 0
		for nr,player in pairs(TOOLS:GetCharacters()) do
			local c = WM:CreateControl('$(parent)Player'..nr, CS4_PlayersListScrollChild, CT_BUTTON)
			c:SetAnchor(3,CS4_PlayersListScrollChild,3,0,(nr-1)*31)
			c:SetDimensions(240,30)
			c:SetNormalTexture('CraftStore4/grey.dds')
			c:SetMouseOverTexture('CraftStore4/over.dds')
			c:SetText('|t8:5:x.dds|t'..player)
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetClickSound('Click')
			c:SetFont('CSFont')
			c:SetNormalFontColor(1,1,1,1)
			c:SetMouseOverFontColor(1,0.66,0.2,1)
			c:SetHandler('OnMouseEnter', function(self) self:GetNamedChild('Ereaser'):SetHidden(false) end)
			c:SetHandler('OnMouseExit', function(self) self:GetNamedChild('Ereaser'):SetHidden(true) end)
			c:SetHandler('OnClicked', function() PLAYER:SetPlayer(player); PLAYER:GetPlayerResearch() end)
			local e = WM:CreateControl('$(parent)Ereaser', c, CT_BUTTON)
			e:SetAnchor(8,c,8,-24,0)
			e:SetDimensions(16,16)
			e:SetNormalTexture('CraftStore4/cross.dds')
			e:SetMouseOverTexture('CraftStore4/over.dds')
			e:SetHidden(true)
			e:SetClickSound('Click')
			e:SetHandler('OnMouseEnter', function(self) self:SetHidden(false); TT:ShowTooltip(self) end)
			e:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			e:SetHandler('OnClicked', function() PLAYER:DeleteCharacter(player) end)
			e.cs_data = { info = LANG:Get('deleteChar'), anchor = {e,1,4,0,2} }
			count = count + 1
		end
		CS4_PlayersListScrollChild:SetDimensions(240,300)
	end

	function self:DrawMatrix()
		for trait,nr in pairs(TRAIT:GetArmorTraits()) do DrawTraitRow(8,trait,nr,69) end
		for trait,nr in pairs(TRAIT:GetWeaponTraits()) do DrawTraitRow(1,trait,nr,369) end

		local c1 = CreateControl('CS4_ResearchBlock1', CS4_Panel, CT_CONTROL)
		c1:SetAnchor(3,CS4_TraitRow11,9,1,-31)
		c1:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 1, 7 do DrawColumn(CRAFTING_TYPE_CLOTHIER,line,c1,line-1) end

		local c2 = CreateControl('CS4_ResearchBlock2', CS4_Panel, CT_CONTROL)
		c2:SetAnchor(3,c1,9,5,0)
		c2:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 8, 14 do DrawColumn(CRAFTING_TYPE_CLOTHIER,line,c2,line-8) end
		
		local c3 = CreateControl('CS4_ResearchBlock3', CS4_Panel, CT_CONTROL)
		c3:SetAnchor(3,c2,9,5,0)
		c3:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 8, 14 do DrawColumn(CRAFTING_TYPE_BLACKSMITHING,line,c3,line-8) end

		local c4 = CreateControl('CS4_ResearchBlock4', CS4_Panel, CT_CONTROL)
		c4:SetAnchor(3,CS4_TraitRow1,9,1,-31)
		c4:SetDimensions(7*30-1,maxtrait*26+61)
		for line = 1, 7 do DrawColumn(CRAFTING_TYPE_BLACKSMITHING,line,c4,line-1) end
		
		local c5 = CreateControl('CS4_ResearchBlock5', CS4_Panel, CT_CONTROL)
		c5:SetAnchor(3,c3,9,5,0)
		c5:SetDimensions(30,maxtrait*26+61)
		DrawColumn(CRAFTING_TYPE_WOODWORKING,6,c5,0)

		local c6 = CreateControl('CS4_ResearchBlock6', CS4_Panel, CT_CONTROL)
		c6:SetAnchor(3,c4,9,5,0)
		c6:SetDimensions(5*30-1,maxtrait*26+61)
		for line = 1, 5 do DrawColumn(CRAFTING_TYPE_WOODWORKING,line,c6,line-1) end
	end
	
	function self:DrawScenes()
		DrawStyles()
		DrawPlayer()
		CS4_PanelMenu:SetText('|t14:14:CraftStore4/menu.dds|t '..LANG:Get('menu'))
		CS4_PanelSign1:SetText(GetString(SI_ITEMTYPE2)..'|t10:5:x.dds|t')
		CS4_PanelSign2:SetText(LANG:Get('known')..'|t10:5:x.dds|t')
		CS4_PanelSign3:SetText(GetString(SI_ITEMTYPE1)..'|t10:5:x.dds|t')
		CS4_PanelSign4:SetText(LANG:Get('known')..'|t10:5:x.dds|t')
		CS4_CommanderButton1:SetText(LANG:Get('commander')[1])
		CS4_CommanderButton2:SetText(LANG:Get('commander')[2])
		CS4_CommanderButton3:SetText(LANG:Get('commander')[3])
		CS4_CommanderButton4:SetText(LANG:Get('commander')[4])
		CS4_CommanderButton5:SetText(LANG:Get('commander')[5])
		CS4_CommanderButton6:SetText(LANG:Get('commander')[6])
		CS4_PlayersCloseButton:SetHandler('OnClicked', FadePlayers(1))
		CS4_PanelPlayer:SetHandler('OnClicked', function() FadePlayers(1) end)
		CS4_PanelPlayer:SetText(PLAYER:GetPlayer())
		local crafting = {CRAFTING_TYPE_BLACKSMITHING, CRAFTING_TYPE_CLOTHIER, CRAFTING_TYPE_WOODWORKING}
		for _,craft in pairs(crafting) do
			for x = 1,3 do
				c = WM:GetControlByName('CS4_Research'..craft..'Line'..x)
				c:SetHandler('OnMouseEnter', function(self) TT:ShowTooltip(self) end)
				c:SetHandler('OnMouseExit', function(self) TT:HideTooltip(self) end)
			end			
		end			
	end
	
	return self
end

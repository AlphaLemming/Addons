function CraftStore:PANEL()
	self = {}
	local WM = WINDOW_MANAGER
	local cs_tt = CraftStore:TOOLTIP()
	local cs_player = CraftStore:PLAYER()
	local cs_traits = CraftStore:TRAITS()
	local cs_lang = CraftStore:LANGUAGE()
	local _,_,maxtrait = GetSmithingResearchLineInfo(1,1)
	
	local function GetLink(craft,line,trait)
		local start, pos, inc = 1, 0, 0
		if craft == CRAFTING_TYPE_CLOTHIER and line < 8 then start = 1; inc = 1
		elseif craft == CRAFTING_TYPE_CLOTHIER and line > 7 then start = 2; inc = 8
		elseif craft == CRAFTING_TYPE_BLACKSMITHING and line < 8 then start = 3; inc = 1
		elseif craft == CRAFTING_TYPE_BLACKSMITHING and line > 7 then start = 4; inc = 8
		elseif craft == CRAFTING_TYPE_WOODWORKING and line == 1 then start = 5
		elseif craft == CRAFTING_TYPE_WOODWORKING and (line > 1 and line < 6) then start = 6; inc = 1
		elseif craft == CRAFTING_TYPE_WOODWORKING and line == 6 then start = 7 end
		if trait == 9 then pos = CraftStore.traititems[start][2] else pos = (trait-1) * 35 end
		return '|H1:item:'..(CraftStore.traititems[start][1] + (line-inc) + pos)..':0:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:10000:0|h|h'
	end
	
	local function SetIcon(craft,line,trait)
		if not craft or not line or not trait then return end
		local traitname = GetString('SI_ITEMTRAITTYPE',GetSmithingResearchLineTraitInfo(craft,line,trait)) or ''
		local known, store = cs_player:GetTrait(craft,line,trait), cs_player:GetStored(craft,line,trait)
		local tip, chatlink = cs_player:GetTraitSummary(craft,line,trait) or '', GetLink(craft,line,trait)
		local c = WM:GetControlByName('CS4_Craft'..craft..'Line'..line..'Trait'..trait)
		c.cs_data = { info = '|cFFFFFF'..traitname..'|r\n'..tip, trait = chatlink, anchor = {c,3,9,2,0} }
		if known == false then
			if store then
				tip = '\n|t20:20:CraftStore4/plus.dds|t |cE8DFAF'..store.owner..'|r'..tip
				c:SetNormalTexture('CraftStore4/plus_bg.dds')
				c.cs_data = { link = store.link, line = {tip}, trait = chatlink, anchor = {CS4_Panel,3,9,2,0} }
			else c:SetNormalTexture('CraftStore4/cross_bg.dds') end
		elseif known == true then c:SetNormalTexture('CraftStore4/tick_bg.dds')
		else c:SetNormalTexture('CraftStore4/time_bg.dds') end
	end

	local function GetTraitCount(craft,line)
		local count = 0
		for _,trait in pairs(CraftStore.account.player[cs_player:GetPlayer()].research[craft][line]) do
			if trait == true then count = count + 1 end
		end
		return count
	end

	local function SetCount(craft,line)
		if not craft or not line then return end
		WM:GetControlByName('CS4_Craft'..craft..'Line'..line..'Count'):SetText(GetTraitCount(craft,line))
	end
	
	function self:UpdatePanel()
		local crafting = {CRAFTING_TYPE_BLACKSMITHING, CRAFTING_TYPE_CLOTHIER, CRAFTING_TYPE_WOODWORKING}
		for _,craft in pairs(crafting) do
			for line = 1, GetNumSmithingResearchLines(craft) do
				SetCount(craft,line)
				for trait = 1, maxtrait do SetIcon(craft,line,trait) end
			end
		end
	end

	function self:UpdateTrait(craft,line,trait)
		SetIcon(craft,line,trait)
		SetCount(craft,line)
	end

	local function ToChat(text) StartChatInput(CHAT_SYSTEM.textEntry:GetText()..text) end

	local function SetResearch(craft,line,trait)
	end

	local function PostTrait(craft,line,trait)
		ToChat(WM:GetControlByName('CS4_Craft'..craft..'Line'..line..'Trait'..trait).cs_data.trait)
	end
	
	local function SetActive(c,craft,line)
		local char = cs_player:GetActivePlayer()
		for x = 1, GetNumChildren(c) do c:GetChild(x):ToggleHidden() end
		CraftStore.account[char].research[craft][line].active = not CraftStore.account[char].research[craft][line].active
	end

	local function SetAllActive(craft)
		for line = 1, GetNumSmithingLines(craft) do
			local c = WM:GetControlByName('CS4_Craft'..craft..'Line'..line)
			if c then SetActive(c,craft,line) end
		end
	end
	
	local function SetInitalActive(craft,line)
		local char = cs_player:GetActivePlayer()
		local c = WM:GetControlByName('CS4_Craft'..craft..'Line'..line)
		if c then		
			for x = 1, GetNumChildren(c) do c:GetChild(x):SetHidden(not CraftStore.account[char].research[craft][line].active) end
		end
		WM:GetControlByName('CS4_Craft'..craft..'Line'..line..'DisabledTexture'):SetHidden(CraftStore.account[char].research[craft][line].active)
	end	

	local function DrawColumn(craft,line,parent,x)
		local name, icon = GetSmithingResearchLineInfo(craft,line)
		local craftname = GetSkillLineInfo(GetCraftingSkillLineIndices(craft))
		local c = WM:CreateControl('CS4_Craft'..craft..'Line'..line, CS4_Panel, CT_BUTTON)
		c:SetAnchor(3,parent,3,x*30,0)
		c:SetDimensions(29,maxtrait*26+63)
		c:SetNormalTexture('AlphaGear/grey.dds')
		c:SetMouseOverTexture('CraftStore4/over.dds')
		c:SetClickSound('Click')
		c:EnableMouseButton(2,true)
		c:SetHandler('OnMouseEnter', function(self) cs_tt:ShowTooltip(self) end)
		c:SetHandler('OnMouseExit', function(self) cs_tt:HideTooltip(self) end)
		c:SetHandler('OnMouseDown', function(self,button) if button == 1 then SetActive(self,craft,line) else SetAllAcitve(self,craft) end end)
		c.cs_data = { info = zo_strformat('|cFFFFFF<<C:1>>\n<<C:2>>',name,craftname), anchor = {c,3,9,2,0} }
		local x = WM:CreateControl('CS4_Craft'..craft..'Line'..line..'Texture', CS4_Panel, CT_TEXTURE)
		x:SetAnchor(1,c,1,0,2)
		x:SetDrawTier(1)
		x:SetDimensions(27,27)
		x:SetTexture(icon)
		for trait = 1, maxtrait do
			local t = WM:CreateControl('$(parent)Trait'..trait, c, CT_BUTTON)
			t:SetAnchor(3,c,3,2,33+(trait-1)*26)
			t:SetDimensions(25,25)
			t:SetNormalTexture('CraftStore4/dark.dds')
			t:SetMouseOverTexture('CraftStore4/over.dds')
			t:SetClickSound('Click')
			t:EnableMouseButton(2,true)
			t:SetHandler('OnMouseEnter', function(self) cs_tt:ShowTooltip(self) end)
			t:SetHandler('OnMouseExit', function(self) cs_tt:HideTooltip(self) end)
			t:SetHandler('OnMouseDown', function(self,button) if button == 1 then SetResearch(craft,line,trait) else PostTrait(craft,line,trait) end end)
		end
		local l = WM:CreateControl('CS4_Craft'..craft..'Line'..line..'Count', CS4_Panel, CT_BUTTON)
		l:SetAnchor(4,c,4,0,-2)
		l:SetDimensions(25,25)
		l:SetHorizontalAlignment(1)
		l:SetVerticalAlignment(1)
		l:SetFont('CS4Font')
		l:SetNormalFontColor(1,1,1,1)
		l:SetNormalTexture('CraftStore4/dark.dds')
		local x = WM:CreateControl('$(parent)DisabledTexture', c, CT_TEXTURE)
		x:SetAnchor(CENTER)
		x:SetDrawTier(1)
		x:SetDimensions(27,27)
		x:SetTexture('CraftStore4/disabled.dds')
		x:SetHidden(true)
	end

	local function DrawTraitRow(line,trait,nr,y)
		local c = WM:CreateControl('CS4_TraitRow'..trait, CS4_Panel, CT_BUTTON)
		local _,desc = GetSmithingResearchLineTraitInfo(CRAFTING_TYPE_BLACKSMITHING,line,nr)
		local _,name,icon = GetSmithingTraitItemInfo(trait + 1)
		c:SetAnchor(3,CS4_Panel,3,10,y+(nr-1)*26)
		c:SetDimensions(153,25)
		c:SetText(GetString('SI_ITEMTRAITTYPE',trait)..' |t23:23:'..icon..'|t|t5:25:x.dds|t')
		c:SetHorizontalAlignment(2)
		c:SetVerticalAlignment(1)
		c:SetFont('CS4Font')
		c:SetNormalFontColor(1,1,1,1)
		c:SetMouseOverFontColor(1,0.66,0.2,1)
		c:SetNormalTexture('AlphaGear/grey.dds')
		c:SetHandler('OnMouseEnter', function(self) cs_tt:ShowTooltip(self) end)
		c:SetHandler('OnMouseExit', function(self) cs_tt:HideTooltip(self) end)
		c.cs_data = { info = zo_strformat('|cFFFFFF<<C:1>>|r\n<<C:2>>',name,desc), anchor = {c,3,6,0,2} }
	end

	function self:DrawMatrix()
		local cs_trait = CraftStore:TRAITS()

		for trait,nr in pairs(cs_trait:GetArmorTraits()) do DrawTraitRow(8,trait,nr,69) end
		for trait,nr in pairs(cs_trait:GetWeaponTraits()) do DrawTraitRow(1,trait,nr,369) end

		local c1 = CreateControl('CS4_ResearchBlock1', CS4_Panel, CT_CONTROL)
		c1:SetAnchor(3,CS4_TraitRow11,9,1,-32)
		c1:SetDimensions(7*30-1,maxtrait*26+63)
		for line = 1, 7 do DrawColumn(CRAFTING_TYPE_CLOTHIER,line,c1,line-1) end

		local c2 = CreateControl('CS4_ResearchBlock2', CS4_Panel, CT_CONTROL)
		c2:SetAnchor(3,c1,9,5,0)
		c2:SetDimensions(7*30-1,maxtrait*26+63)
		for line = 8, 14 do DrawColumn(CRAFTING_TYPE_CLOTHIER,line,c2,line-8) end
		
		local c3 = CreateControl('CS4_ResearchBlock3', CS4_Panel, CT_CONTROL)
		c3:SetAnchor(3,c2,9,5,0)
		c3:SetDimensions(7*30-1,maxtrait*26+63)
		for line = 8, 14 do DrawColumn(CRAFTING_TYPE_BLACKSMITHING,line,c3,line-8) end

		local c4 = CreateControl('CS4_ResearchBlock4', CS4_Panel, CT_CONTROL)
		c4:SetAnchor(3,CS4_TraitRow1,9,1,-32)
		c4:SetDimensions(7*30-1,maxtrait*26+63)
		for line = 1, 7 do DrawColumn(CRAFTING_TYPE_BLACKSMITHING,line,c4,line-1) end
		
		local c5 = CreateControl('CS4_ResearchBlock5', CS4_Panel, CT_CONTROL)
		c5:SetAnchor(3,c3,9,5,0)
		c5:SetDimensions(30,maxtrait*26+63)
		DrawColumn(CRAFTING_TYPE_WOODWORKING,6,c5,0)

		local c6 = CreateControl('CS4_ResearchBlock6', CS4_Panel, CT_CONTROL)
		c6:SetAnchor(3,c4,9,5,0)
		c6:SetDimensions(5*30-1,maxtrait*26+63)
		for line = 1, 5 do DrawColumn(CRAFTING_TYPE_WOODWORKING,line,c6,line-1) end
	end
	
	return self
end

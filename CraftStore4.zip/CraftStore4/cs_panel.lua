function CraftStore:PANEL()
	self = {}
	local WM = WINDOW_MANAGER
	local cs_player = CraftStore:PLAYER()
	local cs_traits = CraftStore:TRAITS()
	local cs_lang = CraftStore:LANGUAGE()
	
	local function GetLink(craft,line,trait)
		local start, pos, atab, wtab = 0, 0, cs_traits:GetArmorTraits(), cs_traits:GetWeaponTraits()
		if trait == ITEM_TRAIT_TYPE_ARMOR_NIRNHONED or trait == ITEM_TRAIT_TYPE_WEAPON_NIRNHONED then
			pos = CraftStore.traititems[2][3]
		else
			local val = atab[trait] or wtab[trait] or 0
			pos = (val - 1) * CraftStore.traititems[2][2]
		end
		if craft == CRAFTING_TYPE_CLOTHIER and line < 8 then start = 1
		elseif craft == CRAFTING_TYPE_CLOTHIER and line > 7 then start = 2
		elseif craft == CRAFTING_TYPE_BLACKSMITHING and line < 8 then start = 3
		elseif craft == CRAFTING_TYPE_BLACKSMITHING and line > 7 then start = 4
		elseif craft == CRAFTING_TYPE_WOODWORKING and line == 1 then start = 5
		elseif craft == CRAFTING_TYPE_WOODWORKING and (line > 1 and line < 6) then start = 6
		elseif craft == CRAFTING_TYPE_WOODWORKING and line == 6 then start = 7 end
		return '|H1:item:'..(CraftStore.traititems[start][1] + pos)..':0:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h'
	end
	
	local function SetIcon(craft,line,trait)
		if not craft or not line or not trait then return end
		local traitname = GetString('SI_ITEMTRAITTYPE',GetSmithingResearchLineTraitInfo(craft,line,trait))
		local known, store = cs_player:GetTrait(craft,line,trait), cs_player:GetStored(craft,line,trait)
		local tip, link = cs_player:GetTraitSummary(craft,line,trait), GetLink(craft,line,trait)
		local c = WM:GetControlByName('CS4_PanelCraft'..craft..'Line'..line..'Trait'..trait)
		c.data = { info = '|cFFFFFF'..traitname..'|r'..tip..'\n'..cs_lang:Get(bank), trait = link }
		if known == false then
			if store then
				tip = '\n|t20:20:CraftStore4/stored.dds|t |cE8DFAF'..store.owner..'|r'..tip
				c:SetNormalTexture('CraftStore4/stored.dds')
				c.data = { link = store.link, addline = {tip}, trait = link }
			else c:SetNormalTexture('CraftStore4/unknown.dds') end
		elseif known == true then c:SetNormalTexture('CraftStore4/known.dds')
		else c:SetNormalTexture('CraftStore4/timer.dds') end
	end

	local function GetTraitCount(craft,line)
		local count = 0
		for _,trait in pairs(CraftStore.account[cs_player:GetPlayer()].research[craft][line]) do
			if trait == true then count = count + 1 end
		end
		return count
	end

	local function SetCount(craft,line)
		if not craft or not line then return end
		WM:GetControlByName('CS4_PanelCraft'..craft..'Line'..line..'Count'):SetText(GetTraitCount(craft,line))
	end
	
	function self:UpdatePanel()
		local crafting = {CRAFTING_TYPE_BLACKSMITHING, CRAFTING_TYPE_CLOTHIER, CRAFTING_TYPE_WOODWORKING}
		for _,craft in ipairs(crafting) do
			for line = 1, GetNumSmithingResearchLines(craft) do
				SetCount(craft,line)
				local _,_,maxtraits = GetSmithingResearchLineInfo()
				for trait = 1, maxtraits do SetIcon(craft,line,trait) end
			end
		end
	end

	function self:UpdateTrait(craft,line,trait)
		SetIcon(craft,line,trait)
		SetCount(craft,line)
	end
	
	return self
end

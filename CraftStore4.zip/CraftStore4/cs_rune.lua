local EM, WM = EVENT_MANAGER, WINDOW_MANAGER
local MAXCRAFT, ASPECT_SKILL, POTENCY_SKILL = 50, 0, 0
local EXTERN, JOB = false, {0,0}

function CraftStore:RUNE()
	self = {}
	local drop_glyphs = {}
	local crafted_glyphs = {}
	local LANG = CraftStore:LANGUAGE()
	local TOOLS = CraftStore:TOOLS()
	local TT = CraftStore:TOOLTIP()

	local function GetLink(id,quality,rank)
		local color = {19,19,19,19,19,19,19,19,19,115,117,119,121,271,307,365,[0] = 0}
		local adder = {1,1,1,1,1,1,1,1,1,10,10,10,10,1,1,1,[0] = 0}
		local level = {5,10,15,20,25,30,35,40,45,50,50,50,50,50,50,50,[0] = 0}
		return ('|H1:item:%u:%u:%u:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h'):format(id,(color[rank] + quality * adder[rank]),level[rank])
	end

	local function GetGlyphs()
		local bag = SHARED_INVENTORY:GenerateFullSlotData(nil, BAG_BANK, BAG_BACKPACK)
		drop_glyphs = {}
		crafted_glyphs = {}
		for _, data in pairs(bag) do
			local item = data.itemType
			local link = GetItemLink(data.bagId, data.slotIndex)
			local icon = GetItemLinkInfo(link)
			if item == ITEMTYPE_GLYPH_ARMOR or item == ITEMTYPE_GLYPH_WEAPON or item == ITEMTYPE_GLYPH_JEWELRY then
				if IsItemLinkCrafted(link) then table.insert(crafted_glyphs,{ name = zo_strformat('<<C:1>>',data.name), icon = icon, link = link, quality = data.quality, bag = data.bagId, slot = data.slotIndex })
				else table.insert(drop_glyphs,{ name = zo_strformat('<<C:1>>',data.name), icon = icon, link = link, quality = data.quality, bag = data.bagId, slot = data.slotIndex }) end
			end
		end
		table.sort(drop_glyphs,function(a,b) return a.name < b.name end)
		table.sort(crafted_glyphs,function(a,b) return a.name < b.name end)
	end
	
	local function Amount()
		if JOB[2] > MAXCRAFT then JOB[2] = MAXCRAFT end
		CS4_RuneAmount:SetText(JOB[2])
		CS4_RuneAmount:SetColor(1,1,1,1)
	end
	
	local function Create()
		if GetNumBagFreeSlots(BAG_BACKPACK) > 0 then
			local bagP, slotP = TOOLS:ScanBag(JOB[3])
			local bagE, slotE = TOOLS:ScanBag(JOB[4])
			local bagA, slotA = TOOLS:ScanBag(JOB[5])
			CraftEnchantingItem(bagP,slotP,bagE,slotE,bagA,slotA)
			-- if CS.account.option[13] then
				PlaySound('Enchanting_Create_Tooltip_Glow')
			-- end
		else d(LANG:Get('nobagspace')) end
	end

	local function Refine(id,source,all)
		if GetNumBagFreeSlots(BAG_BACKPACK) >= 3 then
			if source == 1 and drop_glyphs[id] then
				ExtractEnchantingItem(drop_glyphs[id].bag, drop_glyphs[id].slot)
				table.remove(drop_glyphs,id)
			elseif source == 2 and crafted_glyphs[id] then
				ExtractEnchantingItem(crafted_glyphs[id].bag, crafted_glyphs[id].slot)
				table.remove(crafted_glyphs,id)
			elseif source == 3 and not all and drop_glyphs[1] then
				local last = table.remove(drop_glyphs)
				ExtractEnchantingItem(last.bag, last.slot)
			elseif source == 3 and all then
				if drop_glyphs[1] then
					local last = table.remove(drop_glyphs)
					ExtractEnchantingItem(last.bag, last.slot)
				elseif crafted_glyphs[1] then
					local last = table.remove(crafted_glyphs)
					ExtractEnchantingItem(last.bag, last.slot)
				end
			end
			PlaySound('Enchanting_Extract_Start_Anim')
		else d(LANG:Get('nobagspace')) end
	end
	
	local function Clear(parent)
		for x = 1, parent:GetNumChildren() do parent:GetChild(x):SetHidden(true) end
	end
	
	local function GetButton(parent,name,ypos,func)
		local c = parent:GetNamedChild(name)
		if not c then
			c = WM:CreateControl('$(parent)'..name,parent,CT_BUTTON)
			c:SetAnchor(3,parent,3,8,8+ypos)
			c:SetDimensions(509,32)
			c:SetFont('CS4Font')
			c:SetClickSound('Click')
			c:EnableMouseButton(2,true)
			c:EnableMouseButton(3,true)
			c:SetMouseOverFontColor(1,0.66,0.2,1)
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetHandler('OnMouseEnter',function(self) TT:ShowTooltip(self) end)
			c:SetHandler('OnMouseExit',function(self) TT:HideTooltip(self) end)
			c:SetHandler('OnMouseDown',function(...) func(...) end)
		end
		return c
	end

	local function ShowEnchant(nr,id,essenceId,potencytype,favorite)
		local color, line, bank, bag, cbag, mark, maxval, fault, fav = {[true]='FF0000',[false]='FFFFFF'}
		local quality, level = CraftStore.character.aspect, CraftStore.character.potency
		if favorite then quality, level = unpack(favorite); fav = true else fav = false end
		local idx, link = id..'_'..quality..'_'..level, GetLink(id,quality,level)
		local potencyId, aspectId = CraftStore.runes[51][potencytype][level], CraftStore.runes[52][quality]
		local potencyLink, essenceLink, aspectLink = GetLink(potencyId,1,1), GetLink(essenceId,1,1), GetLink(aspectId,quality,1)
		local potencySkill, aspectSkill = CraftStore.skillLevel[level], quality - 1
		bag, bank, cbag = GetItemLinkStacks(potencyLink)
		local potencyCount = bag + bank + cbag
		bag, bank, cbag = GetItemLinkStacks(essenceLink)
		local essenceCount = bag + bank + cbag
		bag, bank, cbag = GetItemLinkStacks(aspectLink)
		local aspectCount = bag + bank + cbag
		maxval = math.min(potencyCount, essenceCount, aspectCount)
		if CraftStore.character.favorites[3][idx] then mark = '|t16:16:CraftStore4/star.dds|t ' else mark = '' end
		if aspectSkill > ASPECT_SKILL then fault = color[true] else fault = TOOLS:Quality(quality,1,true) end
		line = zo_strformat('\n|t22:22:<<1>>|t |c<<2>><<C:3>>|r |c<<4>>(<<5>>)|r  ',
			GetItemLinkInfo(potencyLink),color[potencySkill > POTENCY_SKILL],GetItemLinkName(potencyLink),color[potencyCount == 0],potencyCount)
		line = line..zo_strformat('|t22:22:<<1>>|t |c<<2>><<C:3>>|r |c<<4>>(<<5>>)|r  ',
			GetItemLinkInfo(essenceLink),color[essenceCount == 0],GetItemLinkName(essenceLink),color[essenceCount == 0],essenceCount)
		line = line..zo_strformat('|t22:22:<<1>>|t |c<<2>><<C:3>>|r |c<<4>>(<<5>>)|r',
			GetItemLinkInfo(aspectLink),fault,GetItemLinkName(aspectLink),color[aspectCount == 0],aspectCount)
		if maxval == 0 or (aspectSkill > ASPECT_SKILL or potencySkill > POTENCY_SKILL) then color = {1,0,0,1}; fault = true else color = TOOLS:Quality(quality,1); fault = false end
		local c = GetButton(CS4_RuneGlyphSectionScrollChild,'GlyphToCreate'..nr,(nr-1)*32,function(self,button)
			local s = self.cs_data
			if button == 1 and not fault and not EXTERN then
				JOB = {'create', tonumber(CS4_RuneAmount:GetText()) or 1, s.potencyId, s.essenceId, s.aspectId}
				Amount(); Create()
			elseif button == 2 and EXTERN then TOOLS:ToChat(s.link)
			elseif button == 2 then
				JOB = {'create', maxval, s.potencyId, s.essenceId, s.aspectId}
				Amount(); Create()
			elseif button == 3 then
				local id = s.glyphId..'_'..s.quality..'_'..s.level
				if CraftStore.character.favorites[3][id] then CraftStore.character.favorites[3][id] = nil
				else CraftStore.character.favorites[3][id] = {s.glyphId, s.essenceId, s.potencyType, s.quality, s.level} end
				ShowEnchant(s.nr, s.glyphId, s.essenceId, s.potencyType)
			end			
		end)
		c:SetText(zo_strformat('<<1>>|t24:24:<<2>>|t <<C:3>> |c777777(<<4>>)|r',mark,GetItemLinkInfo(link),GetItemLinkName(link),maxval))
		c:SetNormalFontColor(unpack(color))
		c:SetHidden(false)
		c.cs_data = {
			anchor = {CS4_Rune,9,3,2,0},
			line = {line},
			button = {1,2,3},
			link = link,
			nr = nr,
			level = level,
			quality = quality,
			glyphId = id,
			potencyId = potencyId,
			essenceId = essenceId,
			aspectId = aspectId,
			potencyType = potencytype
		}
	end

	local function ShowFavorites()
		local count = 1
		for _,glyph in pairs(CraftStore.character.favorites[3]) do ShowEnchant(count,glyph[1],glyph[2],glyph[3],{glyph[4],glyph[5]}); count = count + 1 end
		CS4_RuneGlyphSectionScrollChild:SetHeight(#CraftStore.character.favorites[3]*30+20)
	end

	local function ShowGlyphs()
		Clear(CS4_RuneGlyphSectionScrollChildRefine)
		local count = 0
		for x, glyph in pairs(drop_glyphs) do
			count = count + 1
			local c = GetButton(CS4_RuneGlyphSectionScrollChildRefine,'GlyphToRefine'..x,(x-1)*32,
			function(self,button) if button == 1 then Refine(x,1,true); ShowGlyphs() end end)
			c:SetHidden(false)
			c:SetText('|t24:24:'..glyph.icon..'|t '..glyph.name)
			c:SetNormalFontColor(unpack(TOOLS:Quality(glyph.quality,1)))
			c.cs_data = { link = glyph.link, anchor = {CS4_Rune,9,3,2,0} }
		end
		for x, glyph in pairs(crafted_glyphs) do
			local c = GetButton(CS4_RuneGlyphSectionScrollChildRefine,'GlyphToRefine'..(count+x),(count+x-1)*32,
			function(self,button) if button == 1 then Refine(x,2,true); ShowGlyphs() end end)
			c:SetHidden(false)
			c:SetText('|t22:22:CraftStore4/hand.dds|t |t24:24:'..glyph.icon..'|t '..glyph.name)
			c:SetNormalFontColor(unpack(TOOLS:Quality(glyph.quality,1)))
			c.cs_data = { link = glyph.link, anchor = {CS4_Rune,9,3,2,0} }
		end
		CS4_RuneGlyphSectionScrollChild:SetHeight(count+#crafted_glyphs*32+20)
	end

	local function ShowCategory()
		table.sort(CraftStore.glyphs[CraftStore.character.enchant],function(a,b) return a[4] < b[4] end)
		for nr, glyph in pairs(CraftStore.glyphs[CraftStore.character.enchant]) do ShowEnchant(nr,glyph[1],glyph[2],glyph[3]) end
		CS4_RuneGlyphSectionScrollChild:SetHeight(#CraftStore.glyphs[CraftStore.character.enchant]*30+20)
	end

	local function Prepare()
		EXTERN = false
		ASPECT_SKILL = GetNonCombatBonus(NON_COMBAT_BONUS_ENCHANTING_RARITY_LEVEL)
		POTENCY_SKILL = GetNonCombatBonus(NON_COMBAT_BONUS_ENCHANTING_LEVEL)
		CS4_RuneLevelButton:SetNormalFontColor(unpack(TOOLS:Quality(CraftStore.character.aspect,1)))
		CS4_RuneAmount:SetText(GetString(SI_TRADING_HOUSE_POSTING_QUANTITY).."...")
		CS4_RuneAmount:SetColor(0.6,0.6,0.6,1)
		CS4_Rune:SetHidden(false)
	end
	
	local function ClearScren()
		CS4_RuneGlyphSectionScrollChildRefine:SetHidden(true)
		CS4_RuneLevelButton:SetHidden(false)
		CS4_RuneExtractAll:SetHidden(true)
		CS4_RuneLevelButton:SetText(zo_strformat('<<1>>',CraftStore.runelevels[CraftStore.character.potency]..'  '..LANG:Get('glyph')[CraftStore.character.potency]))
	end
	
	local function ShowMode(mode)
		JOB = {0,0}
		Clear(CS4_RuneGlyphSectionScrollChild)
		if mode == 'category' then
			ClearScren()
			ShowCategory()
			CraftStore.character.runemode = 'category'
		elseif mode == 'runes' then
			ClearScren()
			ShowRuneMode()
			CraftStore.character.runemode = 'runes'
		elseif mode == 'favorites' then
			ClearScren()
			ShowFavorites()
			CraftStore.character.runemode = 'favorites'
		elseif mode == 'refine' then
			CS4_RuneGlyphSectionScrollChildRefine:SetHidden(false)
			CS4_RuneLevelButton:SetHidden(true)
			CS4_RuneExtractAll:SetHidden(false)
			GetGlyphs()
			ShowGlyphs()
			CraftStore.character.runemode = 'refine'
		end
	end

	function self:Init()
		CraftStore.character.favorites[3] = {}
		EM:RegisterForEvent('CraftStore_RuneStart',EVENT_CRAFTING_STATION_INTERACT,function(eventCode,craftSkill)
			-- if CS.account.option[8] then
				if craftSkill == CRAFTING_TYPE_ENCHANTING then
					Prepare()
					for x = 2, ZO_EnchantingTopLevel:GetNumChildren() do ZO_EnchantingTopLevel:GetChild(x):SetHidden(true) end
					ZO_KeybindStripControl:SetHidden(true)
					local soundPlayer = CRAFTING_RESULTS.enchantSoundPlayer
					soundPlayer.PlaySound = function() return end
					ShowMode(CraftStore.character.runemode)
				end
			-- end
		end)
		EM:RegisterForEvent('CraftStore_RuneEnd',EVENT_END_CRAFTING_STATION_INTERACT,function()
			CS4_Rune:SetHidden(true)
			-- for x = 2, ZO_EnchantingTopLevel:GetNumChildren() do ZO_EnchantingTopLevel:GetChild(x):SetHidden(false) end
		end)
		EM:RegisterForEvent('CraftStore_CraftCompleted',EVENT_CRAFT_COMPLETED,function(eventCode,craftSkill)
			if craftSkill == CRAFTING_TYPE_ENCHANTING then
				if JOB[1] == 'create' and JOB[2] > 1 then
					JOB[2] = JOB[2] - 1
					Amount()
					Create()
				elseif JOB[1] == 'refine' and (crafted_glyphs[1] or drop_glyphs[1]) then
					Refine(1,3,JOB[2])
					ShowGlyphs()
				end
			end
		end)
		CS4_RuneExtractAll:SetText(LANG:Get('refineAll'))
		CS4_RuneExtractAll:SetHandler('OnMouseDown', function(self,button)
			if button == 1 then JOB = {'refine',false}; Refine(1,3,false)
			elseif button == 2 then JOB = {'refine',true}; Refine(1,3,true) end
		end)
		CS4_RuneLevelButton:SetHandler('OnClicked', function() CS4_RuneLevelMenu:ToggleHidden() end)
		CS4_RuneFavoriteButton:SetHandler('OnClicked', function() ShowMode('favorites') end)
		CS4_RuneCreateButton:SetHandler('OnClicked', function() ShowMode('category') end)
		CS4_RuneRefineButton:SetHandler('OnClicked', function() ShowMode('refine') end)
		CS4_RuneArmorButton:SetHandler('OnClicked', function() CraftStore.character.enchant = ITEMTYPE_GLYPH_ARMOR; ShowMode('category') end)
		CS4_RuneWeaponButton:SetHandler('OnClicked', function() CraftStore.character.enchant = ITEMTYPE_GLYPH_WEAPON; ShowMode('category') end)
		CS4_RuneJewelryButton:SetHandler('OnClicked', function() CraftStore.character.enchant = ITEMTYPE_GLYPH_JEWELRY; ShowMode('category') end)
		for x = 1,5 do
			local c, link = WM:GetControlByName('CS4_RuneAspect'..x..'Button'), GetLink(CraftStore.runes[ITEMTYPE_ENCHANTING_RUNE_ASPECT][x],x,1)
			c:SetHandler('OnClicked', function() CraftStore.character.aspect = x; CS4_RuneLevelButton:SetNormalFontColor(unpack(TOOLS:Quality(x,1))); ShowMode('category') end)
			local bag, bank, cbag = GetItemLinkStacks(link)
			c:GetNamedChild('Count'):SetText(bag + bank + cbag)
			c.cs_data = { link = link, anchor = {CS4_Rune,9,3,2,0} }
			c:SetHandler('OnMouseEnter',function(self) TT:ShowTooltip(self) end)
			c:SetHandler('OnMouseExit',function(self) TT:HideTooltip(self) end)
		end
		for x = 1,#CraftStore.runelevels do
			c = WM:CreateControl('$(parent)Button'..x,CS4_RuneLevelMenu,CT_BUTTON)
			c:SetAnchor(3,CS4_RuneLevelMenu,3,10,5+(x-1)*28)
			c:SetDimensions(300,28)
			c:SetDrawTier(1)
			c:SetFont('ZoFontGame')
			c:SetClickSound('Click')
			c:SetNormalFontColor(1,1,1,1)
			c:SetMouseOverFontColor(1,0.66,0.2,1)
			c:SetHorizontalAlignment(0)
			c:SetVerticalAlignment(1)
			c:SetText(zo_strformat('<<1>>',CraftStore.runelevels[x]..'  '..LANG:Get('glyph')[x]))
			c:SetHandler('OnClicked',function() CraftStore.character.potency = x; CS4_RuneLevelMenu:SetHidden(true); ShowMode('category') end)
		end
	end
	
	return self
end
-- function CS.RuneShowSelection()
	-- local color, count = 'FFFFFF', 0
	-- local function RuneSelected()
		-- local essence = SplitLink(CS.RuneGetLink(RUNE.rune[ITEMTYPE_ENCHANTING_RUNE_ESSENCE][CS.character.essence],1,1),3)
		-- for _, enchant in pairs(RUNE.glyph) do
			-- for _, glyph in pairs(enchant) do
				-- if glyph[2] == essence and glyph[3] == CS.character.potencytype then
					-- CS.RuneShow(1,glyph[1],CS.character.aspect,CS.character.potency,essence,glyph[3])
					-- return
				-- end
			-- end
		-- end
	-- end
	-- for x,rune in pairs(RUNE.rune[ITEMTYPE_ENCHANTING_RUNE_POTENCY][1]) do
		-- local link = CS.RuneGetLink(rune,1,1)
		-- local known = GetItemLinkEnchantingRuneName(link)
		-- local bag, bank = GetItemLinkStacks(link)
		-- count = bag + bank
		-- color = QUALITY[GetItemLinkQuality(link)]
		-- if count == 0 then color = {0.4,0.4,0.4} end
		-- if not known then color = {1,0,0} end
		-- local btn = WM:GetControlByName('CS4_RuneGlyphSectionScrollChild1Selector'..x)
		-- if not btn then
			-- btn = WM:CreateControl('CS4_RuneGlyphSectionScrollChild1Selector'..x,CS4_RuneGlyphSectionScrollChildSelection,CT_BUTTON)
			-- btn:SetAnchor(3,nil,3,8,50 + (x-1) * 30)
			-- btn:SetDimensions(160,30)
			-- btn:SetFont('ZoFontGame')
			-- btn:EnableMouseButton(2,true)
			-- btn:SetClickSound('Click')
			-- btn:SetNormalFontColor(color[1],color[2],color[3],1)
			-- btn:SetMouseOverFontColor(1,0.66,0.2,1)
			-- btn:SetHorizontalAlignment(0)
			-- btn:SetVerticalAlignment(1)
			-- btn:SetHandler('OnMouseEnter',function(self) CS.Tooltip(self,true,false,CS4_Rune,'tl') end)
			-- btn:SetHandler('OnMouseExit',function(self) CS.Tooltip(self,false) end)
			-- btn:SetHandler('OnMouseDown',function(self,button)
				-- if button == 1 then
					-- CS.RuneSetValue(3,x,1)
					-- CS4_RuneLevelButton:SetText(L.level..': '..RUNE.level[x])
					-- CS4_RuneHighlight1:SetAnchor(2,WM:GetControlByName('CS4_RuneGlyphSectionScrollChild1Selector'..x),2,-14,0)
					-- RuneSelected()
				-- elseif button == 2 then ToChat(link) end
			-- end)
		-- end
		-- btn:SetText('|t24:24:'..GetItemLinkInfo(link)..'|t '..ZOSF('<<C:1>>',GetItemLinkName(link))..' |c666666('..count..')')
		-- btn.data = { link = link, line = {'|cFFAA33CraftStoreRune:|r '..L.level..' '..RUNE.level[x]} }
	-- end
	-- for x,rune in pairs(RUNE.rune[ITEMTYPE_ENCHANTING_RUNE_POTENCY][2]) do
		-- local link = CS.RuneGetLink(rune,1,1)
		-- local known = GetItemLinkEnchantingRuneName(link)
		-- local bag, bank = GetItemLinkStacks(link)
		-- count = bag + bank
		-- color = QUALITY[GetItemLinkQuality(link)]
		-- if count == 0 then color = {0.4,0.4,0.4} end
		-- if not known then color = {1,0,0} end
		-- local btn = WM:GetControlByName('CS4_RuneGlyphSectionScrollChild2Selector'..x)
		-- if not btn then
			-- btn = WM:CreateControl('CS4_RuneGlyphSectionScrollChild2Selector'..x,CS4_RuneGlyphSectionScrollChildSelection,CT_BUTTON)
			-- btn:SetAnchor(3,nil,3,170,50 + (x-1) * 30)
			-- btn:SetDimensions(160,30)
			-- btn:SetFont('ZoFontGame')
			-- btn:EnableMouseButton(2,true)
			-- btn:SetClickSound('Click')
			-- btn:SetNormalFontColor(color[1],color[2],color[3],1)
			-- btn:SetMouseOverFontColor(1,0.66,0.2,1)
			-- btn:SetHorizontalAlignment(0)
			-- btn:SetVerticalAlignment(1)
			-- btn:SetHandler('OnMouseEnter',function(self) CS.Tooltip(self,true,false,CS4_Rune,'tl') end)
			-- btn:SetHandler('OnMouseExit',function(self) CS.Tooltip(self,false) end)
			-- btn:SetHandler('OnMouseDown',function(self,button)
				-- if button == 1 then
					-- CS.RuneSetValue(3,x,2)
					-- CS4_RuneLevelButton:SetText(L.level..': '..RUNE.level[x])
					-- CS4_RuneHighlight1:SetAnchor(2,WM:GetControlByName('CS4_RuneGlyphSectionScrollChild2Selector'..x),2,-14,0)
					-- RuneSelected()
				-- elseif button == 2 then ToChat(link) end
			-- end)
		-- end
		-- btn:SetText('|t24:24:'..GetItemLinkInfo(link)..'|t '..ZOSF('<<C:1>>',GetItemLinkName(link))..' |c666666('..count..')')
		-- btn.data = { link = link, line = {'|cFFAA33CraftStoreRune:|r '..L.level..' '..RUNE.level[x]} }
	-- end
	-- for x,rune in pairs(RUNE.rune[ITEMTYPE_ENCHANTING_RUNE_ESSENCE]) do
		-- local link = CS.RuneGetLink(rune,1,1)
		-- local known = GetItemLinkEnchantingRuneName(link)
		-- local bag, bank = GetItemLinkStacks(link)
		-- count = bag + bank
		-- color = QUALITY[GetItemLinkQuality(link)]
		-- if count == 0 then color = {0.4,0.4,0.4} end
		-- if not known then color = {1,0,0} end
		-- local btn = WM:GetControlByName('CS4_RuneGlyphSectionScrollChild3Selector'..x)
		-- if not btn then
			-- btn = WM:CreateControl('CS4_RuneGlyphSectionScrollChild3Selector'..x,CS4_RuneGlyphSectionScrollChildSelection,CT_BUTTON)
			-- btn:SetAnchor(3,nil,3,332,50 + (x-1) * 30)
			-- btn:SetDimensions(160,30)
			-- btn:SetFont('ZoFontGame')
			-- btn:EnableMouseButton(2,true)
			-- btn:SetClickSound('Click')
			-- btn:SetNormalFontColor(color[1],color[2],color[3],1)
			-- btn:SetMouseOverFontColor(1,0.66,0.2,1)
			-- btn:SetHorizontalAlignment(0)
			-- btn:SetVerticalAlignment(1)
			-- btn:SetHandler('OnMouseEnter',function(self) CS.Tooltip(self,true,false,CS4_Rune,'tl') end)
			-- btn:SetHandler('OnMouseExit',function(self) CS.Tooltip(self,false) end)
			-- btn:SetHandler('OnMouseDown',function(self,button)
				-- if button == 1 then
					-- CS4_RuneHighlight2:SetAnchor(2,WM:GetControlByName('CS4_RuneGlyphSectionScrollChild3Selector'..x),2,-14,0)
					-- CS.RuneSetValue(4,x)
					-- RuneSelected()
				-- elseif button == 2 then ToChat(link) end
			-- end)
		-- end
		-- btn:SetText('|t24:24:'..GetItemLinkInfo(link)..'|t '..ZOSF('<<C:1>>',GetItemLinkName(link))..' |c666666('..count..')')
		-- btn.data = { link = link }
	-- end
	-- local dot = WM:GetControlByName('CS4_RuneHighlight1')
	-- if not dot then
		-- dot = WM:CreateControl('CS4_RuneHighlight1',CS4_RuneGlyphSectionScrollChildSelection,CT_TEXTURE)
		-- dot:SetAnchor(2,WM:GetControlByName('CS4_RuneGlyphSectionScrollChild'..CS.character.potencytype..'Selector'..CS.character.potency),2,-14,0)
		-- dot:SetDimensions(48,48)
		-- dot:SetColor(1,1,1,1)
		-- dot:SetTexture('esoui/art/quickslots/quickslot_highlight_blob.dds')
	-- end
	-- dot = WM:GetControlByName('CS4_RuneHighlight2')
	-- if not dot then
		-- dot = WM:CreateControl('CS4_RuneHighlight2',CS4_RuneGlyphSectionScrollChildSelection,CT_TEXTURE)
		-- dot:SetAnchor(2,WM:GetControlByName('CS4_RuneGlyphSectionScrollChild3Selector'..CS.character.essence),2,-14,0)
		-- dot:SetDimensions(48,48)
		-- dot:SetColor(1,1,1,1)
		-- dot:SetTexture('esoui/art/quickslots/quickslot_highlight_blob.dds')
	-- end
	-- GlyphDivider:SetHidden(false)
	-- CS4_RuneGlyphSectionScrollChildSelection:SetHidden(false)
	-- CS4_RuneInfo:SetText(GetString(SI_CRAFTING_PERFORM_FREE_CRAFT))
	-- RuneSelected()
-- end
-- function CS.RuneView(mode)
	-- local function Close()
		-- CS4_Rune:SetHidden(true)
		-- CS4_RuneCreateButton:SetHidden(false)
		-- CS4_RuneRefineButton:SetHidden(false)
		-- CS4_RuneHeader:SetWidth(440)
		-- CS4_RuneSearch:SetWidth(150)
		-- CS4_RuneSearchBG:SetWidth(160)
		-- CS4_RuneInfo:SetHidden(false)
		-- CS4_RuneAmount:SetHidden(false)
		-- CS4_RuneAmountLabel:SetHidden(false)
		-- EXTERN = false
	-- end
	-- if ZO_EnchantingTopLevel:IsHidden() then
		-- if mode == 1 and CS4_Rune:IsHidden() then
			-- CS4_RuneCreateButton:SetHidden(true)
			-- CS4_RuneRefineButton:SetHidden(true)
			-- CS4_RuneHeader:SetWidth(522)
			-- CS4_RuneSearch:SetWidth(290)
			-- CS4_RuneSearchBG:SetWidth(300)
			-- CS4_RuneInfo:SetHidden(true)
			-- CS4_RuneAmount:SetHidden(true)
			-- CS4_RuneAmountLabel:SetHidden(true)
			-- EXTERN = true
			-- CS.character.runemode = 'craft'
			-- CS.RuneInitalize()
		-- else Close() end
	-- end
-- end

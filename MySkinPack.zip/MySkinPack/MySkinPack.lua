AlphaGear_RegisterIcon('MySkinPack/MyNewIcon64x64.dds')

-- Thats all. The icons should be in a resoluton of 64 x 64 pixel in DXT5 or ARGB32 dds format.
-- You can add as much icons as you want. Just copy the row and change the icon name.
-- Have fun :)

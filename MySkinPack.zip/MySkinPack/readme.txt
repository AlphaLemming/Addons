Create own icon(s) for AlphaGear 4+
-----------------------------------

This is quite simple.

1. Name the folder (MySkinPack) like you want. This should be the name of this mini-addon.

2. Name the files "MySkinPack.lua" and "MySkinPack.txt" with the same name.

3. Create one or more icons. Resolution should be 64 x 64 pixel, format dds, compression DXT5 or ARGB32.

4. Name your icon(s) like you want. Here is only a "MyNewIcon64x64.dds".

5. Open the "MySkinPack.lua" (should have your name now) and edit the row in there.

   AlphaGear_RegisterIcon('MySkinPack/MyNewIcon64x64.dds')

   Change the path and icon name to yours. Insert as much rows as you have icons with their name.

6. Open the "MySkinPack.txt" (should also have your name now) and change the Title, Author, APIVersion if neccessary to yours.

7. Change the file list to your names.

8. Copy the folder in your ESO folder and activate the addon.

